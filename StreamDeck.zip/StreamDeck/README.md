# StreamDeck — iPhone client for Stremio addons

A native SwiftUI iPhone app (iOS 26+, with iOS 27 Liquid Glass refinements) that browses and plays movies and TV shows from any
Stremio-compatible addon (the open [addon protocol](https://github.com/Stremio/stremio-addon-sdk/blob/master/docs/protocol.md)).
The app ships with only the official Cinemeta metadata addon. You add your own stream addons.

## Features

- **Addons**: install by manifest URL (`https://…/manifest.json` or `stremio://…`), enable/disable, reorder, delete, refresh. Opening a `stremio://` link installs the addon.
- **Browse**: Home rows from every addon catalog, "see all" grids with infinite scroll and genre filter, debounced search across all addons that support search.
- **Details**: backdrop, rating, genres, cast, seasons and episodes, watch progress per episode.
- **Streams**: collected from all addons at once and sorted by quality. Each stream gets badges for **4K / 1080p / 720p, Dolby Vision, HDR10+, HDR10, HLG, Atmos, TrueHD, DTS:X, DTS-HD MA, DD+, 5.1/7.1, HEVC/AV1, REMUX** and a size. You can filter by 4K, 1080p, 720p or HDR, set a minimum quality, and autoplay the best stream.
- **Two internal player engines**:
  - **Apple (AVPlayer)**: true HDR10 / HLG / Dolby Vision output on HDR iPhones, Dolby Atmos (E-AC-3 JOC) with spatial audio, Picture in Picture, AirPlay, and native audio and subtitle menus. Plays MP4, MOV and HLS.
  - **VLC engine (VLCKit)**: MKV, AVI, WebM, HEVC and AV1, plus **DTS, DTS-HD, TrueHD, FLAC and Opus** audio, embedded SRT/ASS/PGS subtitles and addon subtitles. It has its own controls: ±10 s, scrubbing, audio and subtitle track menu, and pinch to zoom.
  - **Automatic mode** chooses Apple for files it can play (to keep real HDR and Atmos) and VLC for everything else. If the Apple player fails, it switches to VLC automatically.
- **External players**: Infuse, VLC, Outplayer, nPlayer, SenPlayer, VidHub. Pick a default in Settings, or long-press a stream to choose a player, copy the link or share it.
- **Library**: watchlist, Continue Watching, and resume from where you stopped.
- **iOS 26/27 design**: Liquid Glass tab bar that minimizes on scroll, a separate search tab, a Continue Watching bottom accessory, zoom transitions from posters, a hero carousel with background extension, glass player controls, and on iOS 27 toolbar minimization on scroll.
- **Settings**: default player, external player, quality filters, preferred audio and subtitle language, and an HDR capability check for the device.

## Build

Requirements: a Mac with Xcode 26+ (Xcode 27 enables the iOS 27-only extras) and [XcodeGen](https://github.com/yonaskolb/XcodeGen).

```bash
brew install xcodegen
cd StreamDeck
xcodegen generate          # creates StreamDeck.xcodeproj and resolves VLCKit via SPM
open StreamDeck.xcodeproj
```

In Xcode, select the StreamDeck target, go to Signing & Capabilities, pick your Team, then run it on your iPhone.
Without XcodeGen, you can create a new iOS App project, drag in the `StreamDeck/` folder, add the package
`https://github.com/tylerjonesio/vlckit-spm` (product `VLCKitSPM`) and use `Resources/Info.plist`.

## Build an IPA

**Option A, GitHub Actions (no Mac needed):** push this folder to a GitHub repo. The workflow
`.github/workflows/build-ipa.yml` builds an unsigned `StreamDeck.ipa` on a macOS runner. Download it from the
run's Artifacts, or push a tag like `v1.0` to attach it to a Release.

**Option B, on a Mac:** `./scripts/build_ipa.sh` writes `build/StreamDeck.ipa`.

The IPA is unsigned. Install it with Sideloadly, AltStore or SideStore, which re-sign it with your Apple ID
(free accounts need a re-sign every 7 days).

## Project layout

```
StreamDeck/
  App/            StreamDeckApp (environment, stremio:// handling)
  Models/         Manifest, Meta (movies/series/episodes), Stream (lenient decoding)
  Services/       AddonClient (protocol HTTP), AddonStore, LibraryStore, AppSettings
  Utils/          StreamQuality (4K/HDR/DV/audio parser + scoring)
  Player/         PlaybackCoordinator (engine routing + fallback), NativePlayerView (AVKit),
                  VLCPlayerView (VLCKit + custom controls), ExternalPlayer (URL schemes)
  Views/          Home, Search, Library, Addons, Settings, Detail, Stream list
```

## Notes and limits

- Real HDR and Dolby Vision output needs an HDR iPhone (iPhone 12 or newer) and the Apple engine. The VLC engine tone-maps HDR to SDR.
- iOS cannot decode DTS or TrueHD in AVPlayer, so those streams go to the VLC engine (stereo or multichannel PCM output) or to an external player such as Infuse.
- The app plays streams that have a direct `url` (HTTP or HLS). Torrent-only results (`infoHash` with no URL) are hidden by default, since iOS has no built-in torrent engine.
- `NSAllowsArbitraryLoads` is turned on because many addons and self-hosted servers use plain HTTP.
- App Store review usually rejects general addon clients. Plan on personal sideloading or TestFlight.
- Only use addons and content that you have the rights to stream.
