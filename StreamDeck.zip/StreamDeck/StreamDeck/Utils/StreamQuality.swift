import Foundation

enum Resolution: Int, Comparable, CaseIterable, Codable {
    case unknown = 0, sd = 1, hd720 = 2, hd1080 = 3, uhd4k = 4
    static func < (l: Self, r: Self) -> Bool { l.rawValue < r.rawValue }
    var label: String {
        switch self {
        case .uhd4k: return "4K"
        case .hd1080: return "1080p"
        case .hd720: return "720p"
        case .sd: return "SD"
        case .unknown: return "?"
        }
    }
}

enum HDRFormat: String, CaseIterable, Codable {
    case dolbyVision = "DV", hdr10Plus = "HDR10+", hdr10 = "HDR10", hdr = "HDR", hlg = "HLG"
}

enum AudioFormat: String, CaseIterable, Codable {
    case atmos = "Atmos", trueHD = "TrueHD", dtsX = "DTS:X", dtsHDMA = "DTS-HD MA", dts = "DTS",
         eac3 = "DD+", ac3 = "DD", aac = "AAC", opus = "Opus", flac = "FLAC"

    /// Formats Apple's AVPlayer cannot decode -> must use the VLC engine or an external player.
    var needsSoftwareDecoder: Bool {
        switch self {
        case .trueHD, .dtsX, .dtsHDMA, .dts, .opus, .flac: return true
        default: return false
        }
    }
}

/// Quality information parsed from the addon's stream name/title/filename.
struct StreamQuality: Hashable {
    var resolution: Resolution = .unknown
    var hdr: [HDRFormat] = []
    var audio: [AudioFormat] = []
    var codec: String?           // HEVC, AV1, H.264
    var container: String?       // mkv, mp4, m3u8
    var sizeBytes: Int64?
    var channels: String?        // 5.1 / 7.1
    var isRemux = false

    var isHDR: Bool { !hdr.isEmpty }

    /// True when Apple's native player can likely play it (keeps real HDR / Dolby Vision / Atmos output).
    var nativeCompatible: Bool {
        if let c = container, ["mkv", "avi", "webm", "ts", "wmv", "flv"].contains(c) { return false }
        if audio.contains(where: \.needsSoftwareDecoder) { return false }
        if codec == "AV1" { return false }   // hardware AV1 only on A17 Pro+, safer in VLC
        return true
    }

    var score: Int {
        var s = resolution.rawValue * 1000
        if hdr.contains(.dolbyVision) { s += 300 } else if hdr.contains(.hdr10Plus) { s += 250 } else if isHDR { s += 200 }
        if audio.contains(.atmos) { s += 60 } else if audio.contains(.trueHD) || audio.contains(.dtsHDMA) { s += 50 } else if audio.contains(.eac3) { s += 30 }
        if isRemux { s += 40 }
        return s
    }

    var badges: [String] {
        var b: [String] = []
        if resolution != .unknown { b.append(resolution.label) }
        b += hdr.map(\.rawValue)
        b += audio.prefix(2).map(\.rawValue)
        if let channels { b.append(channels) }
        if let codec { b.append(codec) }
        if isRemux { b.append("REMUX") }
        return b
    }

    var sizeLabel: String? {
        guard let sizeBytes, sizeBytes > 0 else { return nil }
        return ByteCountFormatter.string(fromByteCount: sizeBytes, countStyle: .file)
    }

    static func parse(_ stream: AddonStream) -> StreamQuality {
        let text = stream.descriptor
        let t = text.lowercased()
        var q = StreamQuality()

        func has(_ pattern: String) -> Bool {
            t.range(of: pattern, options: .regularExpression) != nil
        }

        // Resolution
        if has(#"\b(2160p?|4k|uhd)\b"#) { q.resolution = .uhd4k }
        else if has(#"\b1080[pi]?\b|\bfhd\b"#) { q.resolution = .hd1080 }
        else if has(#"\b720p?\b"#) { q.resolution = .hd720 }
        else if has(#"\b(480p?|576p?|360p?|sd|dvdrip)\b"#) { q.resolution = .sd }

        // HDR
        if has(#"\b(dv|dovi|dolby[ ._-]?vision)\b"#) { q.hdr.append(.dolbyVision) }
        if has(#"hdr10\+|hdr10plus"#) { q.hdr.append(.hdr10Plus) }
        else if has(#"\bhdr10\b"#) { q.hdr.append(.hdr10) }
        else if has(#"\bhdr\b"#) { q.hdr.append(.hdr) }
        if has(#"\bhlg\b"#) { q.hdr.append(.hlg) }

        // Audio
        if has(#"atmos"#) { q.audio.append(.atmos) }
        if has(#"truehd"#) { q.audio.append(.trueHD) }
        if has(#"dts[ ._-]?x\b"#) { q.audio.append(.dtsX) }
        else if has(#"dts[ ._-]?hd"#) { q.audio.append(.dtsHDMA) }
        else if has(#"\bdts\b"#) { q.audio.append(.dts) }
        if has(#"\b(ddp|dd\+|eac3|e-ac-3)"#) { q.audio.append(.eac3) }
        else if has(#"\b(dd|ac3|dolby digital)\b"#) { q.audio.append(.ac3) }
        if has(#"\baac\b"#) { q.audio.append(.aac) }
        if has(#"\bopus\b"#) { q.audio.append(.opus) }
        if has(#"\bflac\b"#) { q.audio.append(.flac) }
        if has(#"(?<!\d)7[ .]1\b"#) { q.channels = "7.1" } else if has(#"(?<!\d)5[ .]1\b"#) { q.channels = "5.1" }

        // Codec
        if has(#"\b(hevc|x265|h[ .]?265)\b"#) { q.codec = "HEVC" }
        else if has(#"\bav1\b"#) { q.codec = "AV1" }
        else if has(#"\b(avc|x264|h[ .]?264)\b"#) { q.codec = "H.264" }

        q.isRemux = has(#"\bremux\b"#)

        // Container: filename hint first, then URL path extension
        let candidates = [stream.behaviorHints?.filename, stream.url.flatMap { URL(string: $0)?.path }]
        for c in candidates.compactMap({ $0?.lowercased() }) {
            let ext = (c as NSString).pathExtension
            if !ext.isEmpty { q.container = ext; break }
        }
        if q.container == nil {
            if has(#"\.mkv\b|\bmkv\b"#) { q.container = "mkv" } else if has(#"\.mp4\b"#) { q.container = "mp4" }
        }

        // Size
        if let s = stream.behaviorHints?.videoSize { q.sizeBytes = s }
        else if let m = text.range(of: #"(\d+(?:[.,]\d+)?)\s?(GB|MB)"#, options: [.regularExpression, .caseInsensitive]) {
            let part = String(text[m]).uppercased().replacingOccurrences(of: ",", with: ".")
            let num = Double(part.filter { "0123456789.".contains($0) }) ?? 0
            q.sizeBytes = Int64(num * (part.contains("GB") ? 1_000_000_000 : 1_000_000))
        }
        return q
    }
}
