import Foundation

/// Stremio addon manifest (https://github.com/Stremio/stremio-addon-sdk/blob/master/docs/api/responses/manifest.md)
struct AddonManifest: Codable, Hashable {
    var id: String
    var version: String
    var name: String
    var description: String?
    var logo: String?
    var types: [String]
    var resources: [AddonResource]
    var catalogs: [CatalogDescriptor]
    var idPrefixes: [String]?

    enum CodingKeys: String, CodingKey { case id, version, name, description, logo, types, resources, catalogs, idPrefixes }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id)
        version = (try? c.decode(String.self, forKey: .version)) ?? "0.0.0"
        name = (try? c.decode(String.self, forKey: .name)) ?? id
        description = try? c.decode(String.self, forKey: .description)
        logo = try? c.decode(String.self, forKey: .logo)
        types = (try? c.decode([String].self, forKey: .types)) ?? []
        resources = (try? c.decode([AddonResource].self, forKey: .resources)) ?? []
        catalogs = (try? c.decode([CatalogDescriptor].self, forKey: .catalogs)) ?? []
        idPrefixes = try? c.decode([String].self, forKey: .idPrefixes)
    }

    /// Does this addon provide `resource` for `type` and `id`?
    func supports(_ resource: String, type: String, id: String? = nil) -> Bool {
        guard let r = resources.first(where: { $0.name == resource }) else { return false }
        let types = r.types ?? self.types
        guard types.contains(type) else { return false }
        let prefixes = r.idPrefixes ?? idPrefixes
        if let id, let prefixes, !prefixes.isEmpty {
            return prefixes.contains { id.hasPrefix($0) }
        }
        return true
    }
}

/// Resources may be either a plain string ("stream") or an object.
struct AddonResource: Codable, Hashable {
    var name: String
    var types: [String]?
    var idPrefixes: [String]?

    init(from decoder: Decoder) throws {
        if let s = try? decoder.singleValueContainer().decode(String.self) {
            name = s; types = nil; idPrefixes = nil; return
        }
        let c = try decoder.container(keyedBy: CodingKeys.self)
        name = try c.decode(String.self, forKey: .name)
        types = try? c.decode([String].self, forKey: .types)
        idPrefixes = try? c.decode([String].self, forKey: .idPrefixes)
    }
}

struct CatalogDescriptor: Codable, Hashable {
    var type: String
    var id: String
    var name: String?
    var extra: [CatalogExtra]?
    var extraSupported: [String]?
    var extraRequired: [String]?

    var supportsSearch: Bool {
        (extra?.contains { $0.name == "search" } ?? false) || (extraSupported?.contains("search") ?? false)
    }
    /// Catalogs that need an argument (search, genre...) can't be shown on the home screen.
    var requiresExtra: Bool {
        (extra?.contains { $0.isRequired == true } ?? false) || !(extraRequired ?? []).isEmpty
    }
    var genres: [String] { extra?.first { $0.name == "genre" }?.options ?? [] }
}

struct CatalogExtra: Codable, Hashable {
    var name: String
    var isRequired: Bool?
    var options: [String]?
}

/// An installed addon = manifest + transport URL.
struct InstalledAddon: Codable, Identifiable, Hashable {
    var transportURL: URL          // .../manifest.json
    var manifest: AddonManifest
    var enabled: Bool = true
    var id: String { transportURL.absoluteString }

    var baseURL: URL {
        var s = transportURL.absoluteString
        if s.hasSuffix("/manifest.json") { s.removeLast("/manifest.json".count) }
        return URL(string: s)!
    }
}
