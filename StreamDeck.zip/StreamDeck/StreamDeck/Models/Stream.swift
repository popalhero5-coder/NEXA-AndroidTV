import Foundation

struct StreamResponse: Decodable {
    var streams: [AddonStream]
    private struct Lossy: Decodable { let value: AddonStream?
        init(from d: Decoder) throws { value = try? AddonStream(from: d) } }
    enum CodingKeys: String, CodingKey { case streams }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        streams = ((try? c.decode([Lossy].self, forKey: .streams)) ?? []).compactMap(\.value)
    }
}
struct SubtitlesResponse: Decodable { var subtitles: [AddonSubtitle] }

struct AddonSubtitle: Decodable, Hashable {
    var id: String?
    var url: String
    var lang: String

    enum CodingKeys: String, CodingKey { case id, url, lang }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        url = try c.decode(String.self, forKey: .url)
        lang = (try? c.decode(String.self, forKey: .lang)) ?? "und"
        id = (try? c.decode(String.self, forKey: .id)) ?? (try? c.decode(Int.self, forKey: .id)).map(String.init)
    }
}

/// Stream object (https://github.com/Stremio/stremio-addon-sdk/blob/master/docs/api/responses/stream.md)
struct AddonStream: Decodable, Hashable {
    var url: String?
    var externalUrl: String?
    var ytId: String?
    var infoHash: String?
    var name: String?
    var title: String?
    var description: String?
    var behaviorHints: BehaviorHints?
    var subtitles: [AddonSubtitle]?

    enum CodingKeys: String, CodingKey { case url, externalUrl, ytId, infoHash, name, title, description, behaviorHints, subtitles }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        url = try? c.decode(String.self, forKey: .url)
        externalUrl = try? c.decode(String.self, forKey: .externalUrl)
        ytId = try? c.decode(String.self, forKey: .ytId)
        infoHash = try? c.decode(String.self, forKey: .infoHash)
        name = try? c.decode(String.self, forKey: .name)
        title = try? c.decode(String.self, forKey: .title)
        description = try? c.decode(String.self, forKey: .description)
        behaviorHints = try? c.decode(BehaviorHints.self, forKey: .behaviorHints)
        subtitles = try? c.decode([AddonSubtitle].self, forKey: .subtitles)
    }

    struct BehaviorHints: Decodable, Hashable {
        var notWebReady: Bool?
        var bingeGroup: String?
        var filename: String?
        var videoSize: Int64?
        var proxyHeaders: ProxyHeaders?
    }
    struct ProxyHeaders: Decodable, Hashable {
        var request: [String: String]?
    }

    /// Text used to detect quality tags.
    var descriptor: String {
        [name, title, description, behaviorHints?.filename].compactMap { $0 }.joined(separator: " ")
    }
    var playableURL: URL? { url.flatMap(URL.init(string:)) }
    var requestHeaders: [String: String] { behaviorHints?.proxyHeaders?.request ?? [:] }
}

/// A stream plus the addon it came from and parsed quality.
struct ResolvedStream: Identifiable, Hashable {
    let id = UUID()
    let stream: AddonStream
    let addonName: String
    let quality: StreamQuality

    static func == (l: Self, r: Self) -> Bool { l.id == r.id }
    func hash(into h: inout Hasher) { h.combine(id) }
}
