import Foundation

/// Meta preview (catalog item) and full meta object share most fields.
struct MetaItem: Codable, Identifiable, Hashable {
    var id: String
    var type: String
    var name: String
    var poster: String?
    var posterShape: String?
    var background: String?
    var logo: String?
    var description: String?
    var releaseInfo: String?
    var imdbRating: String?
    var runtime: String?
    var genres: [String]?
    var cast: [String]?
    var director: [String]?
    var videos: [MetaVideo]?

    enum CodingKeys: String, CodingKey {
        case id, type, name, poster, posterShape, background, logo, description, releaseInfo, imdbRating, runtime, genres, cast, director, videos
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id)
        type = (try? c.decode(String.self, forKey: .type)) ?? "movie"
        name = (try? c.decode(String.self, forKey: .name)) ?? id
        poster = try? c.decode(String.self, forKey: .poster)
        posterShape = try? c.decode(String.self, forKey: .posterShape)
        background = try? c.decode(String.self, forKey: .background)
        logo = try? c.decode(String.self, forKey: .logo)
        description = try? c.decode(String.self, forKey: .description)
        releaseInfo = (try? c.decode(String.self, forKey: .releaseInfo)) ?? (try? c.decode(Int.self, forKey: .releaseInfo)).map(String.init)
        imdbRating = (try? c.decode(String.self, forKey: .imdbRating)) ?? (try? c.decode(Double.self, forKey: .imdbRating)).map { String($0) }
        runtime = try? c.decode(String.self, forKey: .runtime)
        genres = try? c.decode([String].self, forKey: .genres)
        cast = try? c.decode([String].self, forKey: .cast)
        director = try? c.decode([String].self, forKey: .director)
        videos = try? c.decode([MetaVideo].self, forKey: .videos)
    }

    init(id: String, type: String, name: String, poster: String?) {
        self.id = id; self.type = type; self.name = name; self.poster = poster
    }

    var posterURL: URL? { poster.flatMap(URL.init(string:)) }
    var backgroundURL: URL? { (background ?? poster).flatMap(URL.init(string:)) }
    var isSeries: Bool { type == "series" || type == "anime" || (videos?.count ?? 0) > 1 }

    var seasons: [Int] {
        Array(Set((videos ?? []).compactMap { $0.season })).sorted { a, b in
            if a == 0 { return false }; if b == 0 { return true }; return a < b   // specials last
        }
    }
    func episodes(season: Int) -> [MetaVideo] {
        (videos ?? []).filter { $0.season == season }.sorted { ($0.episode ?? 0) < ($1.episode ?? 0) }
    }
}

struct MetaVideo: Codable, Identifiable, Hashable {
    var id: String          // e.g. tt0944947:1:1
    var title: String?
    var name: String?
    var season: Int?
    var episode: Int?
    var released: String?
    var thumbnail: String?
    var overview: String?

    enum CodingKeys: String, CodingKey { case id, title, name, season, episode, number, released, thumbnail, overview, description }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decode(String.self, forKey: .id)
        title = try? c.decode(String.self, forKey: .title)
        name = try? c.decode(String.self, forKey: .name)
        season = try? c.decode(Int.self, forKey: .season)
        episode = (try? c.decode(Int.self, forKey: .episode)) ?? (try? c.decode(Int.self, forKey: .number))
        released = try? c.decode(String.self, forKey: .released)
        thumbnail = try? c.decode(String.self, forKey: .thumbnail)
        overview = (try? c.decode(String.self, forKey: .overview)) ?? (try? c.decode(String.self, forKey: .description))
    }

    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(id, forKey: .id)
        try c.encodeIfPresent(title, forKey: .title)
        try c.encodeIfPresent(name, forKey: .name)
        try c.encodeIfPresent(season, forKey: .season)
        try c.encodeIfPresent(episode, forKey: .episode)
        try c.encodeIfPresent(released, forKey: .released)
        try c.encodeIfPresent(thumbnail, forKey: .thumbnail)
        try c.encodeIfPresent(overview, forKey: .overview)
    }

    var displayTitle: String { title ?? name ?? "Episode \(episode ?? 0)" }
    var label: String { "S\(season ?? 0)E\(episode ?? 0)" }
}

struct CatalogResponse: Decodable { var metas: [MetaItem] }
struct MetaResponse: Decodable { var meta: MetaItem }
