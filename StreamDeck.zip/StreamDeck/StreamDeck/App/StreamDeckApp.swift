import SwiftUI

@main
struct StreamDeckApp: App {
    @StateObject private var addons = AddonStore()
    @StateObject private var library = LibraryStore()
    @StateObject private var settings = AppSettings()
    @StateObject private var playback = PlaybackCoordinator()

    var body: some Scene {
        WindowGroup {
            RootTabView()
                .environmentObject(addons)
                .environmentObject(library)
                .environmentObject(settings)
                .environmentObject(playback)
                .preferredColorScheme(.dark)
                .onOpenURL { url in
                    // stremio://host/manifest.json  or  streamdeck://install?url=...
                    let raw: String
                    if url.scheme == "streamdeck",
                       let q = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "url" })?.value {
                        raw = q
                    } else { raw = url.absoluteString }
                    Task { try? await addons.install(raw) }
                }
        }
    }
}
