import SwiftUI

/// Decides which engine plays a stream and handles fallbacks.
@MainActor
final class PlaybackCoordinator: ObservableObject {
    @Published var active: PlayerEngine?
    @Published var message: String?

    func play(_ resolved: ResolvedStream, meta: MetaItem, video: MetaVideo?, subtitles: [AddonSubtitle],
              settings: AppSettings, library: LibraryStore, forceEngine: PlayerChoice? = nil) {
        let s = resolved.stream
        if let ext = s.externalUrl, let u = URL(string: ext), s.url == nil {
            UIApplication.shared.open(u); return
        }
        guard let url = s.playableURL else {
            message = "This stream has no direct video URL (for example a torrent-only result), so it can't be played here."
            return
        }
        let videoId = video?.id ?? meta.id
        let subtitle = video.map { "\($0.label) · \($0.displayTitle)" }
        var req = PlaybackRequest(url: url, headers: s.requestHeaders,
                                  title: video.map { "\(meta.name) — \($0.label)" } ?? meta.name,
                                  videoId: videoId, entry: LibraryEntry(meta, subtitle: subtitle),
                                  quality: resolved.quality)
        req.subtitles = (s.subtitles ?? []) + subtitles
        req.startPosition = library.resumePosition(videoId) ?? 0

        switch forceEngine ?? settings.playerChoice {
        case .external:
            openExternal(url, player: settings.externalPlayer)
        case .native:
            active = .native(req)
        case .vlc:
            active = .vlc(req)
        case .auto:
            // Apple player keeps real HDR/Dolby Vision/Atmos output; VLC covers everything else.
            active = resolved.quality.nativeCompatible ? .native(req) : .vlc(req)
        }
    }

    /// Resume the most recent item straight from the tab bar accessory.
    func resume(_ p: WatchProgress, settings: AppSettings) {
        guard let raw = p.lastURL, let url = URL(string: raw) else { return }
        var req = PlaybackRequest(url: url, headers: p.lastHeaders ?? [:], title: p.meta.name,
                                  videoId: p.videoId, entry: p.meta, quality: StreamQuality())
        req.startPosition = p.position
        switch settings.playerChoice {
        case .external: openExternal(url, player: settings.externalPlayer)
        case .vlc: active = .vlc(req)
        default:
            let ext = url.pathExtension.lowercased()
            active = ["mkv", "avi", "webm"].contains(ext) ? .vlc(req) : .native(req)
        }
    }

    func openExternal(_ url: URL, player: ExternalPlayer) {
        Task {
            let ok = await player.open(url)
            if !ok { message = "\(player.name) isn't installed. Install it from the App Store or choose another player in Settings." }
        }
    }

    /// Called when the Apple player can't decode a file: retry with the VLC engine.
    func fallbackToVLC(from req: PlaybackRequest) {
        active = nil
        Task {
            try? await Task.sleep(for: .milliseconds(600))
            active = .vlc(req)
        }
    }
}
