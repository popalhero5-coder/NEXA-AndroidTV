import UIKit

/// External iOS players reachable via URL schemes (declared in LSApplicationQueriesSchemes).
enum ExternalPlayer: String, CaseIterable, Identifiable, Codable {
    case infuse, vlc, outplayer, nplayer, senplayer, vidhub
    var id: String { rawValue }

    var name: String {
        switch self {
        case .infuse: "Infuse"
        case .vlc: "VLC"
        case .outplayer: "Outplayer"
        case .nplayer: "nPlayer"
        case .senplayer: "SenPlayer"
        case .vidhub: "VidHub"
        }
    }

    func deepLink(for url: URL) -> URL? {
        let allowed = CharacterSet.alphanumerics.union(CharacterSet(charactersIn: "-._~"))
        let encoded = url.absoluteString.addingPercentEncoding(withAllowedCharacters: allowed) ?? url.absoluteString
        let raw = url.absoluteString
        switch self {
        case .infuse:    return URL(string: "infuse://x-callback-url/play?url=\(encoded)")
        case .vlc:       return URL(string: "vlc-x-callback://x-callback-url/stream?url=\(encoded)")
        case .outplayer: return URL(string: "outplayer://\(raw)")
        case .nplayer:   return URL(string: "nplayer-\(raw)")
        case .senplayer: return URL(string: "senplayer://x-callback-url/play?url=\(encoded)")
        case .vidhub:    return URL(string: "open-vidhub://x-callback-url/open?url=\(encoded)")
        }
    }

    var isInstalled: Bool {
        guard let probe = deepLink(for: URL(string: "https://example.com/a.mp4")!) else { return false }
        return UIApplication.shared.canOpenURL(probe)
    }

    @MainActor
    func open(_ url: URL) async -> Bool {
        guard let link = deepLink(for: url) else { return false }
        return await UIApplication.shared.open(link)
    }
}
