import Foundation

/// Everything a player needs to start playback.
struct PlaybackRequest: Identifiable {
    let id = UUID()
    let url: URL
    let headers: [String: String]
    let title: String
    let videoId: String
    let entry: LibraryEntry
    let quality: StreamQuality
    var subtitles: [AddonSubtitle] = []
    var startPosition: Double = 0
}

enum PlayerEngine: Identifiable { case native(PlaybackRequest), vlc(PlaybackRequest)
    var id: UUID { switch self { case .native(let r), .vlc(let r): r.id } }
}
