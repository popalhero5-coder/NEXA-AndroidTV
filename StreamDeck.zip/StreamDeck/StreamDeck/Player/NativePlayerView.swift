import SwiftUI
import AVKit

/// Apple AVPlayer engine. Outputs true HDR10 / HLG / Dolby Vision on HDR iPhones,
/// Dolby Atmos (E-AC-3 JOC) with spatial audio, PiP and AirPlay. Plays MP4/MOV/HLS.
struct NativePlayerView: UIViewControllerRepresentable {
    let request: PlaybackRequest
    let preferredAudioLang: String
    let preferredSubtitleLang: String
    var onProgress: (Double, Double) -> Void
    var onFailure: (String) -> Void
    var onClose: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback, policy: .longFormVideo)
        try? AVAudioSession.sharedInstance().setActive(true)

        var options: [String: Any] = [:]
        if !request.headers.isEmpty { options["AVURLAssetHTTPHeaderFieldsKey"] = request.headers }
        let asset = AVURLAsset(url: request.url, options: options)
        let item = AVPlayerItem(asset: asset)
        item.preferredForwardBufferDuration = 30
        // Let 4K HDR streams pick their best variant; no artificial cap.
        item.preferredPeakBitRate = 0
        item.preferredMaximumResolution = .zero

        let player = AVPlayer(playerItem: item)
        player.allowsExternalPlayback = true
        player.appliesMediaSelectionCriteriaAutomatically = true
        if !preferredAudioLang.isEmpty {
            player.setMediaSelectionCriteria(AVPlayerMediaSelectionCriteria(preferredLanguages: [preferredAudioLang], preferredMediaCharacteristics: nil), forMediaCharacteristic: .audible)
        }
        if !preferredSubtitleLang.isEmpty {
            player.setMediaSelectionCriteria(AVPlayerMediaSelectionCriteria(preferredLanguages: [preferredSubtitleLang], preferredMediaCharacteristics: nil), forMediaCharacteristic: .legible)
        }

        let vc = AVPlayerViewController()
        vc.player = player
        vc.allowsPictureInPicturePlayback = true
        vc.canStartPictureInPictureAutomaticallyFromInline = true
        vc.delegate = context.coordinator
        vc.title = request.title
        context.coordinator.attach(player: player, item: item)

        if request.startPosition > 0 {
            player.seek(to: CMTime(seconds: request.startPosition, preferredTimescale: 600))
        }
        player.play()
        return vc
    }

    func updateUIViewController(_ vc: AVPlayerViewController, context: Context) {}

    static func dismantleUIViewController(_ vc: AVPlayerViewController, coordinator: Coordinator) {
        coordinator.saveNow()
        vc.player?.pause()
        coordinator.detach()
    }

    final class Coordinator: NSObject, AVPlayerViewControllerDelegate {
        let parent: NativePlayerView
        private var timeObserver: Any?
        private var statusObs: NSKeyValueObservation?
        private weak var player: AVPlayer?

        init(_ p: NativePlayerView) { parent = p }

        func attach(player: AVPlayer, item: AVPlayerItem) {
            self.player = player
            timeObserver = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 10, preferredTimescale: 1), queue: .main) { [weak self] _ in
                self?.saveNow()
            }
            statusObs = item.observe(\.status) { [weak self] item, _ in
                guard item.status == .failed else { return }
                let msg = item.error?.localizedDescription ?? "This format isn't supported by the Apple player."
                DispatchQueue.main.async { self?.parent.onFailure(msg) }
            }
        }

        func saveNow() {
            guard let p = player, let item = p.currentItem else { return }
            let pos = p.currentTime().seconds, dur = item.duration.seconds
            if pos.isFinite, dur.isFinite { parent.onProgress(pos, dur) }
        }

        func detach() {
            if let t = timeObserver { player?.removeTimeObserver(t) }
            timeObserver = nil; statusObs = nil
        }

        func playerViewController(_ vc: AVPlayerViewController, willEndFullScreenPresentationWithAnimationCoordinator c: UIViewControllerTransitionCoordinator) {
            c.animate(alongsideTransition: nil) { [weak self] ctx in
                if !ctx.isCancelled { self?.parent.onClose() }
            }
        }
    }
}

/// Full-screen wrapper with a close button.
struct NativePlayerScreen: View {
    let request: PlaybackRequest
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var library: LibraryStore
    @Environment(\.dismiss) private var dismiss
    var onFallback: (String) -> Void

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            NativePlayerView(
                request: request,
                preferredAudioLang: settings.preferredAudioLang,
                preferredSubtitleLang: settings.preferredSubtitleLang,
                onProgress: { pos, dur in library.save(request, position: pos, duration: dur) },
                onFailure: { msg in onFallback(msg) },
                onClose: { dismiss() })
            .ignoresSafeArea()

            Button { dismiss() } label: {
                Image(systemName: "xmark").font(.headline).frame(width: 44, height: 44)
            }
            .buttonStyle(.glass)
            .buttonBorderShape(.circle)
            .padding(.top, 8).padding(.trailing, 16)
        }
        .statusBarHidden()
    }
}
