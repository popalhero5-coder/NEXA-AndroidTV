import SwiftUI
import AVFoundation
import VLCKitSPM

/// VLC (libVLC / FFmpeg) engine: plays MKV, AVI, WebM, HEVC/AV1, DTS, DTS-HD, TrueHD, FLAC,
/// embedded ASS/SRT/PGS subtitles. HDR content is tone-mapped to the display.
@MainActor
final class VLCPlayerModel: NSObject, ObservableObject, VLCMediaPlayerDelegate {
    let player = VLCMediaPlayer()
    @Published var isPlaying = false
    @Published var isBuffering = true
    @Published var position: Double = 0     // seconds
    @Published var duration: Double = 0
    @Published var audioTracks: [MediaTrack] = []
    @Published var subtitleTracks: [MediaTrack] = []
    @Published var currentAudio: Int32 = -1
    @Published var currentSubtitle: Int32 = -1
    @Published var error: String?
    @Published var fill = false

    private let request: PlaybackRequest
    var onProgress: ((Double, Double) -> Void)?
    private var lastSaved: Double = 0

    init(request: PlaybackRequest) {
        self.request = request
        super.init()
        let media = VLCMedia(url: request.url)
        media.addOption(":network-caching=3000")
        if request.startPosition > 0 { media.addOption(":start-time=\(Int(request.startPosition))") }
        if let ua = request.headers["User-Agent"] ?? request.headers["user-agent"] { media.addOption(":http-user-agent=\(ua)") }
        if let ref = request.headers["Referer"] ?? request.headers["referer"] { media.addOption(":http-referrer=\(ref)") }
        player.media = media
        player.delegate = self
        for sub in request.subtitles.prefix(10) {
            if let u = URL(string: sub.url) { _ = player.addPlaybackSlave(u, type: .subtitle, enforce: false) }
        }
    }

    func attach(_ view: UIView) { player.drawable = view }
    func start() {
        try? AVAudioSessionHelper.activate()
        player.play()
    }
    func togglePlay() { player.isPlaying ? player.pause() : player.play() }
    func skip(_ s: Int32) { s > 0 ? player.jumpForward(s) : player.jumpBackward(-s) }
    func seek(to seconds: Double) {
        guard duration > 0 else { return }
        player.position = Float(seconds / duration)
    }
    func setAudio(_ i: Int32) { player.currentAudioTrackIndex = i; currentAudio = i }
    func setSubtitle(_ i: Int32) { player.currentVideoSubTitleIndex = i; currentSubtitle = i }
    private var cropString: UnsafeMutablePointer<CChar>?
    /// Zoom-to-fill: crop the video to the screen's aspect ratio (pinch or button).
    func toggleFill() {
        fill.toggle()
        if let old = cropString { free(old); cropString = nil }
        if fill, let view = player.drawable as? UIView, view.bounds.height > 0 {
            let b = view.bounds.size
            cropString = strdup("\(Int(b.width)):\(Int(b.height))")
        }
        player.videoCropGeometry = cropString
    }
    func stop() {
        save(force: true)
        player.stop()
    }

    private func save(force: Bool = false) {
        guard duration > 0, force || abs(position - lastSaved) >= 10 else { return }
        lastSaved = position
        onProgress?(position, duration)
    }

    private func refreshTracks() {
        func pairs(_ idx: [Any]?, _ names: [Any]?) -> [MediaTrack] {
            let i = (idx as? [NSNumber])?.map(\.int32Value) ?? []
            let n = (names as? [String]) ?? []
            return zip(i, n).map { MediaTrack(id: $0, name: $1) }
        }
        audioTracks = pairs(player.audioTrackIndexes, player.audioTrackNames)
        subtitleTracks = pairs(player.videoSubTitlesIndexes, player.videoSubTitlesNames)
        currentAudio = player.currentAudioTrackIndex
        currentSubtitle = player.currentVideoSubTitleIndex
    }

    // MARK: VLCMediaPlayerDelegate
    nonisolated func mediaPlayerStateChanged(_ aNotification: Notification) {
        Task { @MainActor in
            switch player.state {
            case .buffering: isBuffering = !player.isPlaying
            case .playing: isBuffering = false; isPlaying = true; refreshTracks()
            case .paused: isPlaying = false; save(force: true)
            case .stopped, .ended: isPlaying = false; save(force: true)
            case .error: error = "VLC couldn't open this stream."
            default: break
            }
            isPlaying = player.isPlaying
        }
    }

    nonisolated func mediaPlayerTimeChanged(_ aNotification: Notification) {
        Task { @MainActor in
            position = Double(player.time.intValue) / 1000
            if let len = player.media?.length.intValue, len > 0 { duration = Double(len) / 1000 }
            isBuffering = false
            if audioTracks.isEmpty { refreshTracks() }
            save()
        }
    }
}

struct MediaTrack: Identifiable, Hashable { let id: Int32; let name: String }

enum AVAudioSessionHelper {
    static func activate() throws {
        try AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback, policy: .longFormVideo)
        try AVAudioSession.sharedInstance().setActive(true)
    }
}

private struct VLCDrawable: UIViewRepresentable {
    let model: VLCPlayerModel
    func makeUIView(context: Context) -> UIView {
        let v = UIView(); v.backgroundColor = .black
        model.attach(v)
        return v
    }
    func updateUIView(_ uiView: UIView, context: Context) {}
}

struct VLCPlayerScreen: View {
    @StateObject private var model: VLCPlayerModel
    @EnvironmentObject var library: LibraryStore
    @Environment(\.dismiss) private var dismiss
    @State private var showControls = true
    @State private var scrubbing = false
    @State private var scrubValue: Double = 0
    @State private var hideTask: Task<Void, Never>?
    let request: PlaybackRequest

    init(request: PlaybackRequest) {
        self.request = request
        _model = StateObject(wrappedValue: VLCPlayerModel(request: request))
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VLCDrawable(model: model).ignoresSafeArea()
                .contentShape(Rectangle())
                .onTapGesture { withAnimation { showControls.toggle() }; scheduleHide() }
                .gesture(MagnificationGesture().onEnded { s in if (s > 1) != model.fill { model.toggleFill() } })

            if model.isBuffering { ProgressView().controlSize(.large).tint(.white) }

            if showControls { controls.transition(.opacity) }
        }
        .statusBarHidden()
        .persistentSystemOverlays(.hidden)
        .onAppear {
            model.onProgress = { [request, library] pos, dur in
                library.save(request, position: pos, duration: dur)
            }
            model.start(); scheduleHide()
        }
        .onDisappear { model.stop() }
        .alert("Playback error", isPresented: .constant(model.error != nil)) {
            Button("Close") { dismiss() }
        } message: { Text(model.error ?? "") }
    }

    private var controls: some View {
        VStack {
            HStack(spacing: 16) {
                Button { dismiss() } label: { Image(systemName: "xmark").font(.title3.weight(.semibold)) }
                VStack(alignment: .leading, spacing: 2) {
                    Text(request.title).font(.headline).lineLimit(1)
                    Text(request.quality.badges.joined(separator: " · ")).font(.caption).foregroundStyle(.white.opacity(0.7))
                }
                Spacer()
                trackMenu
                Button { model.toggleFill() } label: {
                    Image(systemName: model.fill ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right")
                }
            }
            .padding(.horizontal, 18).padding(.vertical, 12)
            .glassEffect(.regular, in: .capsule)
            .padding(.horizontal).padding(.top, 8)

            Spacer()

            GlassEffectContainer(spacing: 40) {
                HStack(spacing: 40) {
                    Button { model.skip(-10); scheduleHide() } label: {
                        Image(systemName: "gobackward.10").font(.system(size: 26)).frame(width: 64, height: 64)
                    }
                    .buttonStyle(.glass).buttonBorderShape(.circle)
                    Button { model.togglePlay(); scheduleHide() } label: {
                        Image(systemName: model.isPlaying ? "pause.fill" : "play.fill").font(.system(size: 36))
                            .contentTransition(.symbolEffect(.replace)).frame(width: 88, height: 88)
                    }
                    .buttonStyle(.glass).buttonBorderShape(.circle)
                    Button { model.skip(10); scheduleHide() } label: {
                        Image(systemName: "goforward.10").font(.system(size: 26)).frame(width: 64, height: 64)
                    }
                    .buttonStyle(.glass).buttonBorderShape(.circle)
                }
            }

            Spacer()

            VStack(spacing: 4) {
                Slider(value: Binding(get: { scrubbing ? scrubValue : model.position },
                                      set: { scrubValue = $0 }),
                       in: 0...max(model.duration, 1)) { editing in
                    scrubbing = editing
                    if !editing { model.seek(to: scrubValue) }
                    scheduleHide()
                }
                HStack {
                    Text(format(scrubbing ? scrubValue : model.position))
                    Spacer()
                    Text("-" + format(max(model.duration - model.position, 0)))
                }
                .font(.caption.monospacedDigit())
            }
            .padding(.horizontal, 20).padding(.vertical, 14)
            .glassEffect(.regular, in: .rect(cornerRadius: 28))
            .padding(.horizontal).padding(.bottom, 8)
        }
        .foregroundStyle(.white)
        .tint(.white)
    }

    private var trackMenu: some View {
        Menu {
            Section("Audio") {
                ForEach(model.audioTracks) { t in
                    Button { model.setAudio(t.id) } label: {
                        if t.id == model.currentAudio { Label(t.name, systemImage: "checkmark") } else { Text(t.name) }
                    }
                }
            }
            Section("Subtitles") {
                ForEach(model.subtitleTracks) { t in
                    Button { model.setSubtitle(t.id) } label: {
                        if t.id == model.currentSubtitle { Label(t.name, systemImage: "checkmark") } else { Text(t.name) }
                    }
                }
            }
        } label: { Image(systemName: "captions.bubble") }
    }

    private func scheduleHide() {
        hideTask?.cancel()
        hideTask = Task {
            try? await Task.sleep(for: .seconds(4))
            if !Task.isCancelled, model.isPlaying, !scrubbing { withAnimation { showControls = false } }
        }
    }

    private func format(_ s: Double) -> String {
        guard s.isFinite else { return "0:00" }
        let t = Int(s); let h = t / 3600, m = (t % 3600) / 60, sec = t % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, sec) : String(format: "%d:%02d", m, sec)
    }
}
