import SwiftUI

struct LibraryView: View {
    @EnvironmentObject var library: LibraryStore
    private let cols = [GridItem(.adaptive(minimum: 105), spacing: 12)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                if !library.continueWatching.isEmpty {
                    Text("Continue watching").font(.title3.bold())
                    ForEach(library.continueWatching) { p in
                        NavigationLink(value: p.meta.asMeta) {
                            HStack(spacing: 12) {
                                PosterCard(meta: p.meta.asMeta, width: 60)
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(p.meta.name).font(.headline)
                                    if let s = p.meta.subtitle { Text(s).font(.caption).foregroundStyle(.secondary) }
                                    ProgressView(value: p.fraction).tint(.red)
                                    Text("\(Int((p.duration - p.position) / 60)) min left").font(.caption2).foregroundStyle(.secondary)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                        .contextMenu { Button("Remove", role: .destructive) { library.clearProgress(p.videoId) } }
                    }
                }
                Text("My library").font(.title3.bold())
                if library.watchlist.isEmpty {
                    Text("Titles you add appear here.").foregroundStyle(.secondary)
                }
                LazyVGrid(columns: cols, spacing: 16) {
                    ForEach(library.watchlist) { e in
                        NavigationLink(value: e.asMeta) { PosterCard(meta: e.asMeta, width: 105) }.buttonStyle(.plain)
                    }
                }
            }.padding()
        }
        .navigationTitle("Library")
        .navigationDestination(for: MetaItem.self) { MetaDetailView(preview: $0) }
    }
}
