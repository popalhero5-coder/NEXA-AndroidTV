import SwiftUI
import AVFoundation

struct SettingsView: View {
    @EnvironmentObject var settings: AppSettings
    @State private var hdrSupported = false

    var body: some View {
        Form {
            Section {
                Picker("Default player", selection: $settings.playerChoice) {
                    ForEach(PlayerChoice.allCases) { Text($0.label).tag($0) }
                }
                Picker("External player", selection: $settings.externalPlayer) {
                    ForEach(ExternalPlayer.allCases) { p in
                        Text(p.name + (p.isInstalled ? "" : " (not installed)")).tag(p)
                    }
                }
                Toggle("Autoplay best stream", isOn: $settings.autoplayBest)
            } header: { Text("Playback") } footer: {
                Text("Automatic uses the Apple player for MP4/HLS (true HDR10, Dolby Vision and Atmos) and the VLC engine for MKV, DTS and TrueHD. Long-press any stream to pick a player.")
            }

            Section("Stream filters") {
                Picker("Minimum quality", selection: $settings.minResolution) {
                    Text("Any").tag(Resolution.unknown)
                    Text("720p").tag(Resolution.hd720)
                    Text("1080p").tag(Resolution.hd1080)
                    Text("4K").tag(Resolution.uhd4k)
                }
                Toggle("HDR / Dolby Vision only", isOn: $settings.hdrOnly)
                Toggle("Hide streams without a direct link", isOn: $settings.hideNonPlayable)
            }

            Section("Languages") {
                TextField("Preferred audio (e.g. en, sv)", text: $settings.preferredAudioLang)
                    .textInputAutocapitalization(.never)
                TextField("Preferred subtitles (empty = off)", text: $settings.preferredSubtitleLang)
                    .textInputAutocapitalization(.never)
            }

            Section("This device") {
                LabeledContent("HDR display", value: hdrSupported ? "Supported" : "Not supported")
                LabeledContent("Dolby Vision / HDR10 decode", value: AVPlayer.eligibleForHDRPlayback ? "Yes" : "No")
            }
        }
        .navigationTitle("Settings")
        .onAppear { hdrSupported = UIScreen.main.potentialEDRHeadroom > 1 }
    }
}
