import SwiftUI

struct PosterCard: View {
    let meta: MetaItem
    var width: CGFloat = 124
    var progress: Double? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            AsyncImage(url: meta.posterURL, transaction: .init(animation: .easeOut(duration: 0.25))) { phase in
                switch phase {
                case .success(let img): img.resizable().scaledToFill().transition(.opacity)
                default:
                    ZStack {
                        LinearGradient(colors: [.gray.opacity(0.35), .gray.opacity(0.15)], startPoint: .top, endPoint: .bottom)
                        Text(meta.name).font(.caption.weight(.semibold)).multilineTextAlignment(.center).padding(8)
                    }
                }
            }
            .frame(width: width, height: width * 1.5)
            .clipShape(.rect(cornerRadius: 16, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 16, style: .continuous).strokeBorder(.white.opacity(0.08))
            }
            .overlay(alignment: .bottom) {
                if let progress {
                    Capsule().fill(.white.opacity(0.25)).frame(height: 4)
                        .overlay(alignment: .leading) {
                            GeometryReader { g in Capsule().fill(.pink).frame(width: g.size.width * progress) }
                        }
                        .padding(8)
                }
            }
            .shadow(color: .black.opacity(0.35), radius: 10, y: 6)

            Text(meta.name).font(.footnote.weight(.medium)).lineLimit(1).frame(width: width, alignment: .leading)
        }
    }
}
