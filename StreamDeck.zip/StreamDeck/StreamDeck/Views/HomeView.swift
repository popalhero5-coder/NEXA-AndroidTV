import SwiftUI

struct HomeView: View {
    @EnvironmentObject var addons: AddonStore
    @EnvironmentObject var library: LibraryStore
    @Namespace private var zoom
    @State private var hero: [MetaItem] = []
    @State private var heroIndex: String?

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 28) {
                if !hero.isEmpty { heroCarousel }

                if !library.continueWatching.isEmpty {
                    Shelf(title: "Continue Watching") {
                        ForEach(library.continueWatching) { p in
                            NavigationLink(value: p.meta.asMeta) {
                                PosterCard(meta: p.meta.asMeta, progress: p.fraction)
                                    .matchedTransitionSource(id: p.meta.id, in: zoom)
                            }.buttonStyle(.plain)
                        }
                    }
                }

                if addons.homeCatalogs.isEmpty {
                    ContentUnavailableView("No catalogs yet", systemImage: "puzzlepiece.extension",
                                           description: Text("Install an addon with catalogs in the Addons tab."))
                        .padding(.top, 120)
                }
                ForEach(addons.homeCatalogs) { ref in
                    CatalogRowView(addon: ref.addon, catalog: ref.catalog, zoom: zoom)
                }
            }
            .padding(.bottom, 24)
        }
        .scrollIndicators(.hidden)
        .ignoresSafeArea(edges: .top)
        .navigationTitle("Home")
        .toolbarVisibility(.hidden, for: .navigationBar)
        .navigationDestination(for: MetaItem.self) { m in
            MetaDetailView(preview: m).navigationTransition(.zoom(sourceID: m.id, in: zoom))
        }
        .task(id: addons.homeCatalogs.first?.id) { await loadHero() }
        .refreshable { await addons.refreshAll() }
    }

    private var heroCarousel: some View {
        ScrollView(.horizontal) {
            LazyHStack(spacing: 0) {
                ForEach(hero) { m in
                    HeroCard(meta: m, zoom: zoom)
                        .containerRelativeFrame(.horizontal)
                        .id(m.id)
                }
            }
            .scrollTargetLayout()
        }
        .scrollTargetBehavior(.paging)
        .scrollPosition(id: $heroIndex)
        .scrollIndicators(.hidden)
        .frame(height: 560)
        .overlay(alignment: .bottom) {
            HStack(spacing: 6) {
                ForEach(hero) { m in
                    Capsule().fill(.white.opacity(m.id == (heroIndex ?? hero.first?.id) ? 0.95 : 0.35))
                        .frame(width: m.id == (heroIndex ?? hero.first?.id) ? 18 : 6, height: 6)
                }
            }
            .animation(.snappy, value: heroIndex)
            .padding(.bottom, 10)
        }
    }

    private func loadHero() async {
        guard hero.isEmpty, let first = addons.homeCatalogs.first else { return }
        let items = (try? await AddonClient.shared.catalog(first.addon, first.catalog)) ?? []
        hero = Array(items.prefix(6))
    }
}

private struct HeroCard: View {
    let meta: MetaItem
    let zoom: Namespace.ID
    @EnvironmentObject var library: LibraryStore

    var body: some View {
        ZStack(alignment: .bottom) {
            AsyncImage(url: meta.backgroundURL) { $0.resizable().scaledToFill() } placeholder: { Color.black }
                .frame(height: 560).clipped()
                .backgroundExtensionEffect()
            LinearGradient(colors: [.clear, .black.opacity(0.35), .black.opacity(0.95)], startPoint: .center, endPoint: .bottom)

            VStack(spacing: 14) {
                if let logo = meta.logo.flatMap(URL.init(string:)) {
                    AsyncImage(url: logo) { $0.resizable().scaledToFit() } placeholder: { title }
                        .frame(maxWidth: 260, maxHeight: 90)
                } else { title }

                if let g = meta.genres, !g.isEmpty {
                    Text(g.prefix(3).joined(separator: " · ")).font(.subheadline).foregroundStyle(.white.opacity(0.8))
                }

                GlassEffectContainer(spacing: 12) {
                    HStack(spacing: 12) {
                        NavigationLink(value: meta) {
                            Label("Watch now", systemImage: "play.fill").font(.headline).frame(maxWidth: 200).padding(.vertical, 4)
                        }
                        .buttonStyle(.glassProminent)
                        .matchedTransitionSource(id: meta.id, in: zoom)

                        Button { library.toggleWatchlist(meta) } label: {
                            Image(systemName: library.inWatchlist(meta.id) ? "checkmark" : "plus")
                                .font(.headline).frame(width: 30, height: 30)
                                .contentTransition(.symbolEffect(.replace))
                        }
                        .buttonStyle(.glass).buttonBorderShape(.circle)
                    }
                }
            }
            .padding(.horizontal, 24).padding(.bottom, 36)
        }
    }

    private var title: some View {
        Text(meta.name).font(.system(size: 38, weight: .heavy, design: .rounded))
            .multilineTextAlignment(.center).lineLimit(2).minimumScaleFactor(0.6)
    }
}

/// Horizontal shelf with a header.
struct Shelf<Content: View, Header: View>: View {
    let header: Header
    let content: Content

    init(title: String, @ViewBuilder content: () -> Content) where Header == Text {
        header = Text(title); self.content = content()
    }
    init(@ViewBuilder header: () -> Header, @ViewBuilder content: () -> Content) {
        self.header = header(); self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            header.font(.title3.weight(.bold)).padding(.horizontal, 20)
            ScrollView(.horizontal) {
                LazyHStack(alignment: .top, spacing: 14) { content }
                    .padding(.horizontal, 20)
                    .scrollTargetLayout()
            }
            .scrollIndicators(.hidden)
            .scrollTargetBehavior(.viewAligned)
        }
    }
}

struct CatalogRowView: View {
    let addon: InstalledAddon
    let catalog: CatalogDescriptor
    let zoom: Namespace.ID
    @State private var items: [MetaItem] = []
    @State private var failed = false

    var title: String { "\(catalog.name ?? catalog.id) \(catalog.type == "series" ? "Series" : catalog.type.capitalized)" }

    var body: some View {
        if !failed {
            Shelf {
                NavigationLink {
                    CatalogGridView(addon: addon, catalog: catalog, title: title, zoom: zoom)
                } label: {
                    HStack(spacing: 4) { Text(title); Image(systemName: "chevron.right").font(.footnote.weight(.bold)).foregroundStyle(.secondary) }
                }
                .buttonStyle(.plain)
            } content: {
                if items.isEmpty {
                    ForEach(0..<6, id: \.self) { _ in
                        RoundedRectangle(cornerRadius: 16, style: .continuous).fill(.gray.opacity(0.18))
                            .frame(width: 124, height: 186)
                    }
                }
                ForEach(items) { m in
                    NavigationLink(value: m) {
                        PosterCard(meta: m).matchedTransitionSource(id: m.id, in: zoom)
                    }.buttonStyle(.plain)
                }
            }
            .task {
                guard items.isEmpty else { return }
                do { items = try await AddonClient.shared.catalog(addon, catalog) } catch { failed = true }
            }
        }
    }
}

struct CatalogGridView: View {
    let addon: InstalledAddon
    let catalog: CatalogDescriptor
    let title: String
    let zoom: Namespace.ID
    @State private var items: [MetaItem] = []
    @State private var genre: String?
    @State private var loading = false
    @State private var reachedEnd = false

    private let cols = [GridItem(.adaptive(minimum: 108), spacing: 14)]

    var body: some View {
        ScrollView {
            LazyVGrid(columns: cols, spacing: 18) {
                ForEach(items) { m in
                    NavigationLink(value: m) {
                        PosterCard(meta: m, width: 108).matchedTransitionSource(id: m.id, in: zoom)
                    }
                    .buttonStyle(.plain)
                    .onAppear { if m == items.last { Task { await load() } } }
                }
            }
            .padding()
            if loading { ProgressView().padding() }
        }
        .navigationTitle(title)
        .modifier(MinimizingNavigationBar())
        .toolbar {
            if !catalog.genres.isEmpty {
                Menu {
                    Button("All genres") { genre = nil }
                    ForEach(catalog.genres, id: \.self) { g in Button(g) { genre = g } }
                } label: { Label(genre ?? "Genre", systemImage: "line.3.horizontal.decrease") }
            }
        }
        .task(id: genre) { items = []; reachedEnd = false; await load() }
    }

    private func load() async {
        guard !loading, !reachedEnd else { return }
        loading = true; defer { loading = false }
        var extra: [String: String] = [:]
        if let genre { extra["genre"] = genre }
        if !items.isEmpty { extra["skip"] = String(items.count) }
        let page = (try? await AddonClient.shared.catalog(addon, catalog, extra: extra)) ?? []
        let new = page.filter { p in !items.contains { $0.id == p.id } }
        if new.isEmpty { reachedEnd = true }
        items += new
    }
}
