import SwiftUI

@MainActor
final class StreamsViewModel: ObservableObject {
    @Published var streams: [ResolvedStream] = []
    @Published var subtitles: [AddonSubtitle] = []
    @Published var loadingAddons: Set<String> = []
    @Published var errors: [String] = []
    @Published var finished = false

    func load(type: String, id: String, addons: AddonStore) async {
        guard streams.isEmpty else { return }
        let sources = addons.addons(for: "stream", type: type, id: id)
        let subSources = addons.addons(for: "subtitles", type: type, id: id)
        loadingAddons = Set(sources.map(\.manifest.name))
        if sources.isEmpty { errors = ["No installed addon provides streams for this title. Add one in the Addons tab."] }

        await withTaskGroup(of: (String, Result<[AddonStream], Error>).self) { group in
            for a in sources {
                group.addTask {
                    do { return (a.manifest.name, .success(try await AddonClient.shared.streams(a, type: type, id: id))) }
                    catch { return (a.manifest.name, .failure(error)) }
                }
            }
            for await (name, result) in group {
                loadingAddons.remove(name)
                switch result {
                case .success(let list):
                    streams += list.map { ResolvedStream(stream: $0, addonName: name, quality: .parse($0)) }
                    streams.sort { $0.quality.score > $1.quality.score }
                case .failure(let e):
                    errors.append("\(name): \(e.localizedDescription)")
                }
            }
        }
        finished = true
        for a in subSources {
            if let subs = try? await AddonClient.shared.subtitles(a, type: type, id: id) { subtitles += subs }
        }
    }
}

struct StreamListView: View {
    let meta: MetaItem
    let video: MetaVideo?

    @EnvironmentObject var addons: AddonStore
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var playback: PlaybackCoordinator
    @ObservedObject var vm: StreamsViewModel
    @State private var resFilter: Resolution?
    @State private var hdrFilter = false
    @State private var didAutoplay = false

    private var filtered: [ResolvedStream] {
        vm.streams.filter { r in
            if settings.hideNonPlayable, r.stream.url == nil, r.stream.externalUrl == nil { return false }
            if r.quality.resolution < settings.minResolution { return false }
            if let resFilter, r.quality.resolution != resFilter { return false }
            if (hdrFilter || settings.hdrOnly), !r.quality.isHDR { return false }
            return true
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            filters
            if !vm.finished {
                HStack(spacing: 8) {
                    ProgressView()
                    Text(vm.loadingAddons.isEmpty ? "Finding streams…" : "Asking \(vm.loadingAddons.sorted().joined(separator: ", "))…").font(.caption).foregroundStyle(.secondary)
                }.padding(.horizontal)
            }
            if filtered.isEmpty && vm.finished {
                VStack(alignment: .leading, spacing: 6) {
                    Text(vm.streams.isEmpty ? "No streams found." : "No streams match the filters.").font(.subheadline)
                    ForEach(vm.errors, id: \.self) { Text($0).font(.caption).foregroundStyle(.secondary) }
                }.padding(.horizontal)
            }
            LazyVStack(spacing: 8) {
                ForEach(filtered) { r in
                    StreamRow(resolved: r)
                        .onTapGesture { play(r) }
                        .contextMenu { menu(for: r) }
                }
            }
            .padding(.horizontal, 20)
        }
        .onChange(of: vm.finished) { _, done in
            if done, settings.autoplayBest, !didAutoplay, let best = filtered.first {
                didAutoplay = true; play(best)
            }
        }
    }

    private var filters: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                chip("All", selected: resFilter == nil && !hdrFilter) { resFilter = nil; hdrFilter = false }
                ForEach([Resolution.uhd4k, .hd1080, .hd720], id: \.self) { r in
                    chip(r.label, selected: resFilter == r) { resFilter = resFilter == r ? nil : r }
                }
                chip("HDR / DV", selected: hdrFilter) { hdrFilter.toggle() }
            }.padding(.horizontal, 20)
        }
    }

    private func chip(_ t: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(t).font(.subheadline.weight(.semibold)).padding(.horizontal, 14).padding(.vertical, 8)
                .foregroundStyle(selected ? .black : .primary)
                .background(selected ? AnyShapeStyle(.white) : AnyShapeStyle(.white.opacity(0.08)), in: Capsule())
        }.buttonStyle(.plain)
    }

    @ViewBuilder private func menu(for r: ResolvedStream) -> some View {
        Button { play(r, engine: .native) } label: { Label("Play in Apple player", systemImage: "play.rectangle") }
        Button { play(r, engine: .vlc) } label: { Label("Play in VLC engine", systemImage: "play.rectangle.on.rectangle") }
        Menu {
            ForEach(ExternalPlayer.allCases) { p in
                Button(p.name) { if let u = r.stream.playableURL { playback.openExternal(u, player: p) } }
            }
        } label: { Label("Open in external player", systemImage: "arrow.up.forward.app") }
        if let u = r.stream.playableURL {
            Button { UIPasteboard.general.url = u } label: { Label("Copy stream link", systemImage: "doc.on.doc") }
            ShareLink(item: u) { Label("Share link", systemImage: "square.and.arrow.up") }
        }
    }

    private func play(_ r: ResolvedStream, engine: PlayerChoice? = nil) {
        playback.play(r, meta: meta, video: video, subtitles: vm.subtitles,
                      settings: settings, library: library, forceEngine: engine)
    }
}

struct StreamRow: View {
    let resolved: ResolvedStream
    var q: StreamQuality { resolved.quality }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                ForEach(q.badges, id: \.self) { b in
                    Text(b).font(.caption2.bold()).padding(.horizontal, 6).padding(.vertical, 3)
                        .background(color(for: b).opacity(0.85), in: RoundedRectangle(cornerRadius: 4))
                }
                Spacer()
                if let s = q.sizeLabel { Text(s).font(.caption).foregroundStyle(.secondary) }
            }
            Text(resolved.stream.title ?? resolved.stream.description ?? resolved.stream.name ?? "Stream")
                .font(.footnote).lineLimit(3)
            HStack {
                Image(systemName: "puzzlepiece.extension.fill").font(.caption2).foregroundStyle(.secondary)
                Text(resolved.addonName + (resolved.stream.name.map { " · " + $0.replacingOccurrences(of: "\n", with: " ") } ?? ""))
                    .font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                Spacer()
                if resolved.stream.url == nil {
                    Text(resolved.stream.externalUrl != nil ? "Opens externally" : "Not playable")
                        .font(.caption2).foregroundStyle(.orange)
                } else if !q.nativeCompatible {
                    Text("VLC engine").font(.caption2).foregroundStyle(.secondary)
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.white.opacity(0.06), in: .rect(cornerRadius: 20, style: .continuous))
        .overlay { RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(.white.opacity(0.07)) }
        .contentShape(Rectangle())
    }

    private func color(for badge: String) -> Color {
        switch badge {
        case "4K": .purple
        case "DV": .pink
        case "HDR10+", "HDR10", "HDR", "HLG": .orange
        case "Atmos", "TrueHD", "DTS:X", "DTS-HD MA": .blue
        case "REMUX": .green
        default: .gray
        }
    }
}
