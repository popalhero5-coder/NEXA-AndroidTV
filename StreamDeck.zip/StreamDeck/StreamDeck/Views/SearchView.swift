import SwiftUI

struct SearchView: View {
    @EnvironmentObject var addons: AddonStore
    @State private var query = ""
    @State private var results: [CatalogRef: [MetaItem]] = [:]
    @State private var loading = false

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 20) {
                if query.isEmpty {
                    ContentUnavailableView("Search movies and series", systemImage: "magnifyingglass",
                                           description: Text("Results come from your installed addons."))
                        .padding(.top, 80)
                }
                ForEach(addons.searchCatalogs) { ref in
                    if let items = results[ref], !items.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("\(ref.catalog.type.capitalized) · \(ref.addon.manifest.name)").font(.title3.bold()).padding(.horizontal)
                            ScrollView(.horizontal, showsIndicators: false) {
                                LazyHStack(spacing: 12) {
                                    ForEach(items) { m in NavigationLink(value: m) { PosterCard(meta: m) }.buttonStyle(.plain) }
                                }.padding(.horizontal)
                            }
                        }
                    }
                }
                if loading { ProgressView().frame(maxWidth: .infinity) }
            }.padding(.vertical)
        }
        .navigationTitle("Search")
        .searchable(text: $query, prompt: "Movies, series…")
        .navigationDestination(for: MetaItem.self) { MetaDetailView(preview: $0) }
        .task(id: query) {
            let q = query.trimmingCharacters(in: .whitespaces)
            guard q.count >= 2 else { results = [:]; return }
            try? await Task.sleep(for: .milliseconds(400))      // debounce
            guard !Task.isCancelled else { return }
            loading = true; defer { loading = false }
            var out: [CatalogRef: [MetaItem]] = [:]
            await withTaskGroup(of: (CatalogRef, [MetaItem]).self) { g in
                for ref in addons.searchCatalogs {
                    g.addTask { (ref, (try? await AddonClient.shared.catalog(ref.addon, ref.catalog, extra: ["search": q])) ?? []) }
                }
                for await (ref, items) in g { out[ref] = items }
            }
            if !Task.isCancelled { results = out }
        }
    }
}
