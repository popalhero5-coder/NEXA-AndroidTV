import SwiftUI

struct AddonsView: View {
    @EnvironmentObject var store: AddonStore
    @State private var url = ""
    @State private var installing = false
    @State private var error: String?

    var body: some View {
        List {
            Section {
                TextField("https://…/manifest.json or stremio://…", text: $url)
                    .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                Button {
                    Task { await install() }
                } label: {
                    HStack { Text("Install addon"); if installing { Spacer(); ProgressView() } }
                }
                .disabled(url.isEmpty || installing)
                if let error { Text(error).font(.caption).foregroundStyle(.red) }
            } header: { Text("Add addon") } footer: {
                Text("Paste the manifest URL of any Stremio-compatible addon. Only install addons for content you have the right to stream.")
            }

            Section("Installed") {
                ForEach(store.addons) { a in
                    HStack(spacing: 12) {
                        AsyncImage(url: a.manifest.logo.flatMap(URL.init(string:))) { $0.resizable().scaledToFit() } placeholder: {
                            Image(systemName: "puzzlepiece.extension").foregroundStyle(.secondary)
                        }.frame(width: 36, height: 36)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(a.manifest.name).font(.headline)
                            Text("v\(a.manifest.version) · " + a.manifest.resources.map(\.name).joined(separator: ", "))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Toggle("", isOn: Binding(get: { a.enabled }, set: { _ in store.toggle(a) })).labelsHidden()
                    }
                    .contextMenu {
                        Button { UIPasteboard.general.string = a.transportURL.absoluteString } label: { Label("Copy manifest URL", systemImage: "doc.on.doc") }
                    }
                }
                .onDelete(perform: store.remove)
                .onMove(perform: store.move)
            }
        }
        .navigationTitle("Addons")
        .toolbar { EditButton() }
        .refreshable { await store.refreshAll() }
    }

    private func install() async {
        installing = true; error = nil
        defer { installing = false }
        do { try await store.install(url); url = "" } catch { self.error = error.localizedDescription }
    }
}
