import SwiftUI

struct RootTabView: View {
    @EnvironmentObject var playback: PlaybackCoordinator
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var settings: AppSettings

    var body: some View {
        TabView {
            Tab("Home", systemImage: "play.house.fill") { NavigationStack { HomeView() } }
            Tab("Library", systemImage: "square.stack.fill") { NavigationStack { LibraryView() } }
            Tab("Addons", systemImage: "puzzlepiece.extension.fill") { NavigationStack { AddonsView() } }
            Tab("Settings", systemImage: "gearshape.fill") { NavigationStack { SettingsView() } }
            Tab(role: .search) { NavigationStack { SearchView() } }
        }
        .tabBarMinimizeBehavior(.onScrollDown)
        .modifier(ResumeAccessory(item: library.latestResumable) { p in playback.resume(p, settings: settings) })
        .tint(.pink)
        .fullScreenCover(item: $playback.active) { engine in
            switch engine {
            case .native(let req):
                NativePlayerScreen(request: req) { _ in playback.fallbackToVLC(from: req) }
            case .vlc(let req):
                VLCPlayerScreen(request: req)
            }
        }
        .alert("Playback", isPresented: Binding(get: { playback.message != nil }, set: { if !$0 { playback.message = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(playback.message ?? "") }
    }
}

/// "Continue watching" mini bar above the Liquid Glass tab bar (iOS 26.1+).
private struct ResumeAccessory: ViewModifier {
    let item: WatchProgress?
    let resume: (WatchProgress) -> Void

    func body(content: Content) -> some View {
        if #available(iOS 26.1, *) {
            content.tabViewBottomAccessory(isEnabled: item != nil) {
                if let item {
                    Button { resume(item) } label: {
                        HStack(spacing: 10) {
                            AsyncImage(url: item.meta.poster.flatMap(URL.init(string:))) { $0.resizable().scaledToFill() }
                                placeholder: { Color.gray.opacity(0.3) }
                                .frame(width: 28, height: 40).clipShape(RoundedRectangle(cornerRadius: 6))
                            VStack(alignment: .leading, spacing: 1) {
                                Text(item.meta.name).font(.subheadline.weight(.semibold)).lineLimit(1)
                                Text(item.meta.subtitle ?? "\(Int((item.duration - item.position) / 60)) min left")
                                    .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer()
                            Image(systemName: "play.fill")
                        }
                        .padding(.horizontal, 14)
                    }
                    .buttonStyle(.plain)
                }
            }
        } else {
            content
        }
    }
}

/// iOS 27: let the navigation bar minimize while scrolling. Ignored on older SDKs/OSes.
struct MinimizingNavigationBar: ViewModifier {
    func body(content: Content) -> some View {
        #if compiler(>=6.4)
        if #available(iOS 27, *) {
            content.toolbarMinimizationBehavior(.automatic, for: .navigationBar)
        } else { content }
        #else
        content
        #endif
    }
}
