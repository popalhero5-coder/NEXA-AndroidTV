import SwiftUI

struct MetaDetailView: View {
    let preview: MetaItem
    @EnvironmentObject var addons: AddonStore
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var playback: PlaybackCoordinator
    @StateObject private var streams = StreamsViewModel()
    @State private var meta: MetaItem?
    @State private var season: Int = 1
    @State private var showAllText = false

    var item: MetaItem { meta ?? preview }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                header
                info.padding(.horizontal, 20)
                if item.isSeries, !item.seasons.isEmpty {
                    episodes
                } else {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Streams").font(.title2.bold()).padding(.horizontal, 20)
                        StreamListView(meta: item, video: nil, vm: streams)
                    }
                }
            }
            .padding(.bottom, 40)
        }
        .scrollIndicators(.hidden)
        .ignoresSafeArea(edges: .top)
        .navigationBarTitleDisplayMode(.inline)
        .modifier(MinimizingNavigationBar())
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { library.toggleWatchlist(item) } label: {
                    Image(systemName: library.inWatchlist(item.id) ? "bookmark.fill" : "bookmark")
                }
            }
        }
        .task { await load() }
    }

    // MARK: Header with stretchy backdrop
    private var header: some View {
        GeometryReader { g in
            let y = g.frame(in: .scrollView).minY
            AsyncImage(url: item.backgroundURL, transaction: .init(animation: .easeOut)) { phase in
                if let img = phase.image { img.resizable().scaledToFill() } else { Color.black }
            }
            .frame(width: g.size.width, height: 440 + max(y, 0))
            .clipped()
            .backgroundExtensionEffect()
            .offset(y: -max(y, 0))
            .overlay(alignment: .bottom) {
                LinearGradient(colors: [.clear, .black.opacity(0.6), Color(.systemBackground)], startPoint: .center, endPoint: .bottom)
                    .frame(height: 260)
            }
        }
        .frame(height: 440)
        .overlay(alignment: .bottomLeading) {
            VStack(alignment: .leading, spacing: 10) {
                if let logo = item.logo.flatMap(URL.init(string:)) {
                    AsyncImage(url: logo) { $0.resizable().scaledToFit() } placeholder: { titleText }
                        .frame(maxWidth: 240, maxHeight: 80, alignment: .leading)
                } else { titleText }
                metaLine
            }
            .padding(.horizontal, 20)
        }
    }

    private var titleText: some View {
        Text(item.name).font(.system(size: 34, weight: .heavy, design: .rounded)).lineLimit(2)
    }

    private var metaLine: some View {
        HStack(spacing: 8) {
            if let r = item.releaseInfo { Text(r) }
            if let rt = item.runtime { Text("·"); Text(rt) }
            if let rating = item.imdbRating {
                Text("·")
                Label(rating, systemImage: "star.fill").labelStyle(.titleAndIcon).foregroundStyle(.yellow)
            }
        }
        .font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
    }

    // MARK: Info + actions
    private var info: some View {
        VStack(alignment: .leading, spacing: 14) {
            GlassEffectContainer(spacing: 12) {
                HStack(spacing: 12) {
                    if item.isSeries, let ep = nextEpisode {
                        NavigationLink { StreamListScreen(meta: item, video: ep) } label: {
                            Label(primaryLabel, systemImage: "play.fill").font(.headline)
                                .frame(maxWidth: .infinity).padding(.vertical, 6)
                        }
                        .buttonStyle(.glassProminent)
                    } else {
                        Button { playPrimary() } label: {
                            Label(primaryLabel, systemImage: "play.fill").font(.headline)
                                .frame(maxWidth: .infinity).padding(.vertical, 6)
                        }
                        .buttonStyle(.glassProminent)
                        .disabled(item.isSeries || streams.streams.isEmpty)
                    }

                    Button { library.toggleWatchlist(item) } label: {
                        Image(systemName: library.inWatchlist(item.id) ? "checkmark" : "plus")
                            .font(.headline).frame(width: 30, height: 30)
                            .contentTransition(.symbolEffect(.replace))
                    }
                    .buttonStyle(.glass).buttonBorderShape(.circle)
                }
            }

            if let g = item.genres, !g.isEmpty {
                ScrollView(.horizontal) {
                    HStack(spacing: 8) {
                        ForEach(g, id: \.self) { Text($0).font(.caption.weight(.semibold)).padding(.horizontal, 10).padding(.vertical, 5)
                            .background(.white.opacity(0.08), in: Capsule()) }
                    }
                }.scrollIndicators(.hidden)
            }

            if let d = item.description {
                Text(d).font(.callout).foregroundStyle(.white.opacity(0.85))
                    .lineLimit(showAllText ? nil : 4)
                    .onTapGesture { withAnimation(.snappy) { showAllText.toggle() } }
            }
            if let c = item.cast, !c.isEmpty {
                Text("Starring ").foregroundStyle(.secondary) + Text(c.prefix(4).joined(separator: ", "))
            }
        }
        .font(.footnote)
    }

    private var primaryLabel: String {
        if item.isSeries {
            guard let ep = nextEpisode else { return "Loading…" }
            return library.progress[ep.id] != nil ? "Resume \(ep.label)" : "Play \(ep.label)"
        }
        if library.resumePosition(item.id) != nil { return "Resume" }
        return streams.streams.isEmpty ? "Finding streams…" : "Play best"
    }

    /// The episode in progress, else the first unwatched, else S1E1.
    private var nextEpisode: MetaVideo? {
        let all = item.seasons.filter { $0 > 0 }.flatMap { item.episodes(season: $0) }
        if let inProgress = all.first(where: { library.progress[$0.id].map { !$0.finished } ?? false }) { return inProgress }
        return all.first(where: { !(library.progress[$0.id]?.finished ?? false) }) ?? all.first
    }

    private func playPrimary() {
        if let best = streams.streams.first(where: { $0.stream.url != nil }) {
            playback.play(best, meta: item, video: nil, subtitles: streams.subtitles, settings: settings, library: library)
        }
    }

    // MARK: Episodes
    private var episodes: some View {
        VStack(alignment: .leading, spacing: 14) {
            ScrollView(.horizontal) {
                HStack(spacing: 8) {
                    ForEach(item.seasons, id: \.self) { s in
                        Button { withAnimation(.snappy) { season = s } } label: {
                            Text(s == 0 ? "Specials" : "Season \(s)").font(.subheadline.weight(.semibold))
                                .padding(.horizontal, 14).padding(.vertical, 8)
                                .foregroundStyle(season == s ? .black : .primary)
                                .background(season == s ? AnyShapeStyle(.white) : AnyShapeStyle(.white.opacity(0.08)), in: Capsule())
                        }
                        .buttonStyle(.plain)
                    }
                }.padding(.horizontal, 20)
            }.scrollIndicators(.hidden)

            LazyVStack(spacing: 4) {
                ForEach(item.episodes(season: season)) { ep in
                    NavigationLink { StreamListScreen(meta: item, video: ep) } label: { EpisodeRow(meta: item, video: ep) }
                        .buttonStyle(.plain)
                }
            }
        }
    }

    private func load() async {
        if meta == nil {
            for addon in addons.addons(for: "meta", type: preview.type, id: preview.id) {
                if let m = try? await AddonClient.shared.meta(addon, type: preview.type, id: preview.id) {
                    meta = m
                    season = m.seasons.first { $0 > 0 } ?? m.seasons.first ?? 1
                    break
                }
            }
        }
        if !item.isSeries { await streams.load(type: item.type, id: item.id, addons: addons) }
    }
}

struct EpisodeRow: View {
    let meta: MetaItem
    let video: MetaVideo
    @EnvironmentObject var library: LibraryStore

    var body: some View {
        HStack(spacing: 14) {
            AsyncImage(url: video.thumbnail.flatMap(URL.init(string:))) { $0.resizable().scaledToFill() } placeholder: {
                ZStack { Color.gray.opacity(0.2); Image(systemName: "play.fill").foregroundStyle(.secondary) }
            }
            .frame(width: 136, height: 78)
            .clipShape(.rect(cornerRadius: 12, style: .continuous))
            .overlay(alignment: .bottom) {
                if let p = library.progress[video.id] {
                    ProgressView(value: p.fraction).tint(.pink).padding(6)
                }
            }
            VStack(alignment: .leading, spacing: 4) {
                Text("Episode \(video.episode ?? 0)").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                Text(video.displayTitle).font(.subheadline.weight(.semibold)).lineLimit(2)
                if let o = video.overview { Text(o).font(.caption).foregroundStyle(.secondary).lineLimit(2) }
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 20).padding(.vertical, 6)
        .contentShape(Rectangle())
    }
}

struct StreamListScreen: View {
    let meta: MetaItem
    let video: MetaVideo
    @EnvironmentObject var addons: AddonStore
    @StateObject private var vm = StreamsViewModel()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if let o = video.overview {
                    Text(o).font(.callout).foregroundStyle(.secondary).padding(.horizontal, 20)
                }
                StreamListView(meta: meta, video: video, vm: vm)
            }.padding(.top)
        }
        .navigationTitle("\(video.label) · \(video.displayTitle)")
        .navigationBarTitleDisplayMode(.inline)
        .modifier(MinimizingNavigationBar())
        .task { await vm.load(type: meta.type, id: video.id, addons: addons) }
    }
}
