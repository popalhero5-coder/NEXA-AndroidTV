import Foundation

enum AddonError: LocalizedError {
    case invalidURL, badResponse(Int)
    var errorDescription: String? {
        switch self {
        case .invalidURL: "That addon URL isn't valid."
        case .badResponse(let c): "The addon responded with HTTP \(c)."
        }
    }
}

/// Minimal client for the Stremio addon HTTP protocol.
struct AddonClient {
    static let shared = AddonClient()

    private let session: URLSession = {
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 15
        cfg.requestCachePolicy = .returnCacheDataElseLoad
        cfg.urlCache = URLCache(memoryCapacity: 20_000_000, diskCapacity: 100_000_000)
        return URLSession(configuration: cfg)
    }()
    private let decoder = JSONDecoder()

    /// Accepts https://.../manifest.json, stremio://.../manifest.json, or a base URL.
    static func normalize(_ raw: String) -> URL? {
        var s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if s.hasPrefix("stremio://") { s = "https://" + s.dropFirst("stremio://".count) }
        if !s.hasPrefix("http://") && !s.hasPrefix("https://") { s = "https://" + s }
        if !s.hasSuffix("manifest.json") { s = s.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/manifest.json" }
        return URL(string: s)
    }

    func fetchManifest(_ url: URL) async throws -> AddonManifest {
        try await get(url)
    }

    func catalog(_ addon: InstalledAddon, _ cat: CatalogDescriptor, extra: [String: String] = [:]) async throws -> [MetaItem] {
        let resp: CatalogResponse = try await get(resourceURL(addon, "catalog", cat.type, cat.id, extra: extra))
        return resp.metas
    }

    func meta(_ addon: InstalledAddon, type: String, id: String) async throws -> MetaItem {
        let resp: MetaResponse = try await get(resourceURL(addon, "meta", type, id))
        return resp.meta
    }

    func streams(_ addon: InstalledAddon, type: String, id: String) async throws -> [AddonStream] {
        let resp: StreamResponse = try await get(resourceURL(addon, "stream", type, id))
        return resp.streams
    }

    func subtitles(_ addon: InstalledAddon, type: String, id: String) async throws -> [AddonSubtitle] {
        let resp: SubtitlesResponse = try await get(resourceURL(addon, "subtitles", type, id))
        return resp.subtitles
    }

    // MARK: helpers

    private func resourceURL(_ addon: InstalledAddon, _ resource: String, _ type: String, _ id: String, extra: [String: String] = [:]) -> URL {
        let allowed = CharacterSet.urlPathAllowed.subtracting(CharacterSet(charactersIn: "/?&=#"))
        func enc(_ s: String) -> String { s.addingPercentEncoding(withAllowedCharacters: allowed) ?? s }
        var path = "/\(resource)/\(enc(type))/\(enc(id))"
        if !extra.isEmpty {
            path += "/" + extra.sorted { $0.key < $1.key }.map { "\(enc($0.key))=\(enc($0.value))" }.joined(separator: "&")
        }
        return URL(string: addon.baseURL.absoluteString + path + ".json")!
    }

    private func get<T: Decodable>(_ url: URL) async throws -> T {
        let (data, response) = try await session.data(from: url)
        if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            throw AddonError.badResponse(http.statusCode)
        }
        return try decoder.decode(T.self, from: data)
    }
}
