import Foundation

struct WatchProgress: Codable, Hashable, Identifiable {
    var id: String { videoId }
    var videoId: String       // movie id or episode id
    var meta: LibraryEntry
    var position: Double
    var duration: Double
    var updated: Date
    var lastURL: String? = nil
    var lastHeaders: [String: String]? = nil
    var fraction: Double { duration > 0 ? position / duration : 0 }
    var finished: Bool { fraction > 0.92 }
}

struct LibraryEntry: Codable, Hashable, Identifiable {
    var id: String
    var type: String
    var name: String
    var poster: String?
    var subtitle: String?     // e.g. "S1E3 · Episode title"
    init(_ m: MetaItem, subtitle: String? = nil) {
        id = m.id; type = m.type; name = m.name; poster = m.poster; self.subtitle = subtitle
    }
    var asMeta: MetaItem { MetaItem(id: id, type: type, name: name, poster: poster) }
}

/// Watchlist + continue-watching, stored in UserDefaults.
@MainActor
final class LibraryStore: ObservableObject {
    @Published private(set) var watchlist: [LibraryEntry] = []
    @Published private(set) var progress: [String: WatchProgress] = [:]

    private let d = UserDefaults.standard
    init() {
        if let a = d.data(forKey: "watchlist"), let v = try? JSONDecoder().decode([LibraryEntry].self, from: a) { watchlist = v }
        if let b = d.data(forKey: "progress"), let v = try? JSONDecoder().decode([String: WatchProgress].self, from: b) { progress = v }
    }

    var continueWatching: [WatchProgress] {
        progress.values.filter { !$0.finished && $0.position > 30 }.sorted { $0.updated > $1.updated }
    }

    func inWatchlist(_ id: String) -> Bool { watchlist.contains { $0.id == id } }
    func toggleWatchlist(_ m: MetaItem) {
        if let i = watchlist.firstIndex(where: { $0.id == m.id }) { watchlist.remove(at: i) }
        else { watchlist.insert(LibraryEntry(m), at: 0) }
        persist()
    }

    func save(videoId: String, entry: LibraryEntry, position: Double, duration: Double) {
        guard duration.isFinite, duration > 0 else { return }
        progress[videoId] = WatchProgress(videoId: videoId, meta: entry, position: position, duration: duration, updated: .now)
        persist()
    }
    func save(_ req: PlaybackRequest, position: Double, duration: Double) {
        guard duration.isFinite, duration > 0 else { return }
        progress[req.videoId] = WatchProgress(videoId: req.videoId, meta: req.entry, position: position, duration: duration,
                                              updated: .now, lastURL: req.url.absoluteString, lastHeaders: req.headers)
        persist()
    }
    var latestResumable: WatchProgress? { continueWatching.first { $0.lastURL != nil } }

    func resumePosition(_ videoId: String) -> Double? {
        guard let p = progress[videoId], !p.finished, p.position > 30 else { return nil }
        return p.position
    }
    func clearProgress(_ videoId: String) { progress[videoId] = nil; persist() }

    private func persist() {
        d.set(try? JSONEncoder().encode(watchlist), forKey: "watchlist")
        d.set(try? JSONEncoder().encode(progress), forKey: "progress")
    }
}
