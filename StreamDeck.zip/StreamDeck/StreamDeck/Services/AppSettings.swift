import Foundation
import SwiftUI

enum PlayerChoice: String, CaseIterable, Identifiable, Codable {
    case auto, native, vlc, external
    var id: String { rawValue }
    var label: String {
        switch self {
        case .auto: "Automatic"
        case .native: "Apple (HDR / Dolby Vision / Atmos)"
        case .vlc: "VLC engine (MKV / DTS / TrueHD)"
        case .external: "External player"
        }
    }
}

/// User preferences persisted in UserDefaults.
@MainActor
final class AppSettings: ObservableObject {
    private let d = UserDefaults.standard

    @Published var playerChoice: PlayerChoice { didSet { d.set(playerChoice.rawValue, forKey: "playerChoice") } }
    @Published var externalPlayer: ExternalPlayer { didSet { d.set(externalPlayer.rawValue, forKey: "externalPlayer") } }
    @Published var minResolution: Resolution { didSet { d.set(minResolution.rawValue, forKey: "minResolution") } }
    @Published var hdrOnly: Bool { didSet { d.set(hdrOnly, forKey: "hdrOnly") } }
    @Published var hideNonPlayable: Bool { didSet { d.set(hideNonPlayable, forKey: "hideNonPlayable") } }
    @Published var autoplayBest: Bool { didSet { d.set(autoplayBest, forKey: "autoplayBest") } }
    @Published var preferredAudioLang: String { didSet { d.set(preferredAudioLang, forKey: "preferredAudioLang") } }
    @Published var preferredSubtitleLang: String { didSet { d.set(preferredSubtitleLang, forKey: "preferredSubtitleLang") } }

    init() {
        playerChoice = PlayerChoice(rawValue: d.string(forKey: "playerChoice") ?? "") ?? .auto
        externalPlayer = ExternalPlayer(rawValue: d.string(forKey: "externalPlayer") ?? "") ?? .infuse
        minResolution = Resolution(rawValue: d.integer(forKey: "minResolution")) ?? .unknown
        hdrOnly = d.bool(forKey: "hdrOnly")
        hideNonPlayable = d.object(forKey: "hideNonPlayable") as? Bool ?? true
        autoplayBest = d.bool(forKey: "autoplayBest")
        preferredAudioLang = d.string(forKey: "preferredAudioLang") ?? "en"
        preferredSubtitleLang = d.string(forKey: "preferredSubtitleLang") ?? ""
    }
}
