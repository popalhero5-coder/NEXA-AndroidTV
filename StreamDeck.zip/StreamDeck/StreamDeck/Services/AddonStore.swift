import Foundation
import SwiftUI

/// Installed addons, persisted as JSON in Application Support.
@MainActor
final class AddonStore: ObservableObject {
    @Published private(set) var addons: [InstalledAddon] = []
    @Published var lastError: String?

    /// Official Stremio metadata addon (catalogs + meta for movies/series). Contains no streams.
    static let defaultAddons = ["https://v3-cinemeta.strem.io/manifest.json"]

    private let fileURL: URL = {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("addons.json")
    }()

    init() {
        if let data = try? Data(contentsOf: fileURL),
           let saved = try? JSONDecoder().decode([InstalledAddon].self, from: data) {
            addons = saved
        } else {
            Task { for url in Self.defaultAddons { try? await install(url) } }
        }
    }

    var enabled: [InstalledAddon] { addons.filter(\.enabled) }

    func install(_ raw: String) async throws {
        guard let url = AddonClient.normalize(raw) else { throw AddonError.invalidURL }
        let manifest = try await AddonClient.shared.fetchManifest(url)
        let addon = InstalledAddon(transportURL: url, manifest: manifest)
        if let i = addons.firstIndex(where: { $0.manifest.id == manifest.id }) {
            addons[i] = addon
        } else {
            addons.append(addon)
        }
        save()
    }

    func remove(at offsets: IndexSet) { addons.remove(atOffsets: offsets); save() }
    func move(from: IndexSet, to: Int) { addons.move(fromOffsets: from, toOffset: to); save() }
    func toggle(_ addon: InstalledAddon) {
        guard let i = addons.firstIndex(of: addon) else { return }
        addons[i].enabled.toggle(); save()
    }

    func refreshAll() async {
        for a in addons { try? await install(a.transportURL.absoluteString) }
    }

    func addons(for resource: String, type: String, id: String? = nil) -> [InstalledAddon] {
        enabled.filter { $0.manifest.supports(resource, type: type, id: id) }
    }

    /// Catalogs that can be shown on Home (no required extras).
    var homeCatalogs: [CatalogRef] {
        enabled.flatMap { a in a.manifest.catalogs.filter { !$0.requiresExtra }.map { CatalogRef(addon: a, catalog: $0) } }
    }
    var searchCatalogs: [CatalogRef] {
        enabled.flatMap { a in a.manifest.catalogs.filter(\.supportsSearch).map { CatalogRef(addon: a, catalog: $0) } }
    }

    private func save() {
        if let data = try? JSONEncoder().encode(addons) { try? data.write(to: fileURL, options: .atomic) }
    }
}

struct CatalogRef: Identifiable, Hashable {
    let addon: InstalledAddon
    let catalog: CatalogDescriptor
    var id: String { "\(addon.id)|\(catalog.type)|\(catalog.id)" }
}
