#!/usr/bin/env bash
# Builds an unsigned StreamDeck.ipa on a Mac (Xcode 26+; Xcode 27 recommended for iOS 27 features).
# Sideload it with Sideloadly, AltStore or SideStore — they re-sign it with your Apple ID.
set -euo pipefail
cd "$(dirname "$0")/.."
command -v xcodegen >/dev/null || brew install xcodegen
xcodegen generate
xcodebuild -project StreamDeck.xcodeproj -scheme StreamDeck -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" clean build
rm -rf Payload StreamDeck.ipa
mkdir Payload
cp -R build/Build/Products/Release-iphoneos/StreamDeck.app Payload/
zip -qry StreamDeck.ipa Payload
rm -rf Payload
echo "Built $(pwd)/StreamDeck.ipa"
