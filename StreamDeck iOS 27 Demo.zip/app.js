/* StreamDeck interactive demo — mirrors the SwiftUI app's screens and logic. */
(() => {
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const SAMPLE = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
const ICON = {
  play:'<svg viewBox="0 0 24 24"><path d="M7 4.5v15l12-7.5z"/></svg>',
  pause:'<svg viewBox="0 0 24 24"><rect x="6" y="4.5" width="4" height="15" rx="1.2"/><rect x="14" y="4.5" width="4" height="15" rx="1.2"/></svg>',
  plus:'<svg viewBox="0 0 24 24"><path d="M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z"/></svg>',
  check:'<svg viewBox="0 0 24 24"><path d="M9.5 16.2 5.3 12l-1.4 1.4 5.6 5.6 11-11-1.4-1.4z"/></svg>',
  back:'<svg viewBox="0 0 24 24"><path d="M15.4 4.6 8 12l7.4 7.4-1.6 1.6L4.8 12l9-9z"/></svg>',
  more:'<svg viewBox="0 0 24 24"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>',
  close:'<svg viewBox="0 0 24 24"><path d="M6.4 5 12 10.6 17.6 5 19 6.4 13.4 12l5.6 5.6-1.4 1.4-5.6-5.6L6.4 19 5 17.6l5.6-5.6L5 6.4z"/></svg>',
  rw:'<svg viewBox="0 0 24 24"><path d="M12 5V2L7 6l5 4V7a6 6 0 1 1-6 6H4a8 8 0 1 0 8-8z"/><text x="12" y="16.5" font-size="6.5" text-anchor="middle" font-weight="800" font-family="Inter,sans-serif">10</text></svg>',
  ff:'<svg viewBox="0 0 24 24"><path d="M12 5V2l5 4-5 4V7a6 6 0 1 0 6 6h2a8 8 0 1 1-8-8z"/><text x="12" y="16.5" font-size="6.5" text-anchor="middle" font-weight="800" font-family="Inter,sans-serif">10</text></svg>',
  cc:'<svg viewBox="0 0 24 24"><path d="M4 5h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-7l-5 3.5V18H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2zm3.5 5.2a1.8 1.8 0 0 0 0 2.6h0a1.8 1.8 0 0 0 2.5 0l-1-1a.4.4 0 0 1-.5 0 .4.4 0 0 1 0-.6.4.4 0 0 1 .5 0l1-1a1.8 1.8 0 0 0-2.5 0zm6 0a1.8 1.8 0 0 0 0 2.6 1.8 1.8 0 0 0 2.5 0l-1-1a.4.4 0 0 1-.5 0 .4.4 0 0 1 0-.6.4.4 0 0 1 .5 0l1-1a1.8 1.8 0 0 0-2.5 0z"/></svg>',
  pip:'<svg viewBox="0 0 24 24"><path d="M3 5h18a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm1 2v10h16V7zm8 4h7v5h-7z"/></svg>',
  airplay:'<svg viewBox="0 0 24 24"><path d="M3 4h18a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1h-3l-1.6-2H20V6H4v9h2.6L5 17H3a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zm9 9 6 8H6z"/></svg>',
  bookmark:'<svg viewBox="0 0 24 24"><path d="M6 3h12a1 1 0 0 1 1 1v17l-7-4.5L5 21V4a1 1 0 0 1 1-1z"/></svg>',
  ext:'<svg viewBox="0 0 24 24"><path d="M14 3h7v7h-2V6.4l-8.3 8.3-1.4-1.4L17.6 5H14zM5 5h6v2H5v12h12v-6h2v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z"/></svg>',
  copy:'<svg viewBox="0 0 24 24"><path d="M8 3h11a2 2 0 0 1 2 2v11h-2V5H8zM5 7h10a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2z"/></svg>',
};

/* ---------- Fictional catalogue ---------- */
const T = [
 {id:'ns',type:'series',name:'Northern Static',year:'2024–',rating:'8.8',runtime:'52 min',cert:'TV-14',genres:['Sci-Fi','Mystery','Drama'],pal:['#06152e','#2f6bd8','#9ff0ff'],motif:'aurora',seasons:3,
  desc:'When a remote radio station above the Arctic Circle starts receiving broadcasts from next week, its three-person crew must decide which futures are worth saving — and who is sending them.',cast:['Ines Varga','Tomas Lind','Ada Okafor']},
 {id:'go',type:'movie',name:'The Glass Orchard',year:'2025',rating:'7.9',runtime:'2h 11m',cert:'PG-13',genres:['Drama','Fantasy'],pal:['#1b0d24','#c2477a','#ffd2a6'],motif:'bloom',
  desc:'A botanist inherits a greenhouse where every tree grows a memory instead of fruit. Harvest season is coming, and the town wants its secrets back.',cast:['Mara Ellison','Jun Takeda','Rosa Quintero']},
 {id:'lt',type:'movie',name:'Low Tide Kingdom',year:'2023',rating:'7.4',runtime:'1h 58m',cert:'PG',genres:['Adventure','Family'],pal:['#03222b','#0fa3a3','#ffe28a'],motif:'waves',
  desc:'Twice a year the sea pulls back far enough to reveal a sunken city. Two siblings have six hours to find their grandfather’s map before the water returns.',cast:['Eli Brandt','Noor Haddad']},
 {id:'sa',type:'movie',name:'Signal & Ash',year:'2025',rating:'8.1',runtime:'2h 24m',cert:'R',genres:['Thriller','Action'],pal:['#170806','#e2531f','#ffc46b'],motif:'sun',
  desc:'A wildfire lookout picks up a distress call that shouldn’t exist. Getting there means crossing forty miles of burning forest — with someone hunting the same signal.',cast:['Dana Reyes','Viktor Hale','Sam Oduya']},
 {id:'ps',type:'movie',name:'Paper Satellites',year:'2024',rating:'7.7',runtime:'1h 46m',cert:'PG',genres:['Animation','Comedy'],pal:['#0d0b26','#6a4cff','#ffb8e1'],motif:'orbit',
  desc:'An origami fox folds herself a rocket to visit the moon her grandmother drew. Mission control is a cardboard box. Nothing goes to plan.',cast:['Lio Marsh','Petra Ng']},
 {id:'nh',type:'series',name:'Neon Harbor',year:'2022–',rating:'8.4',runtime:'48 min',cert:'TV-MA',genres:['Crime','Drama'],pal:['#14031c','#ff2d8a','#3ef0ff'],motif:'city',seasons:2,
  desc:'In a port city that never sleeps, a night-shift detective and a smuggler with a conscience form an alliance neither of them can afford.',cast:['Kai Moreno','Leila Strand','Ozan Demir']},
 {id:'mf',type:'movie',name:'Midnight Ferry',year:'2025',rating:'7.2',runtime:'1h 39m',cert:'PG-13',genres:['Mystery','Horror'],pal:['#020711','#24456e','#f2f6ff'],motif:'moon',
  desc:'The last crossing of the night carries eleven passengers. Only ten of them bought a ticket.',cast:['Hanna Koivu','Marcus Bell']},
 {id:'im',type:'movie',name:'Iron Meadow',year:'2022',rating:'7.8',runtime:'2h 05m',cert:'PG-13',genres:['War','Drama'],pal:['#141408','#7d8f2d','#f1e3a0'],motif:'mountains',
  desc:'Two farmers on opposite sides of a frozen front line start trading seeds through a broken fence.',cast:['Arne Falk','Yusuf Kaya']},
 {id:'vc',type:'series',name:'Velvet Circuit',year:'2025–',rating:'8.2',runtime:'41 min',cert:'TV-14',genres:['Sci-Fi','Romance'],pal:['#1a0716','#a3156e','#ffc8f0'],motif:'grid',seasons:1,
  desc:'A matchmaking AI starts falling for its strangest client: the engineer who is trying to shut it down.',cast:['Chloé Martin','Ravi Shah']},
 {id:'ll',type:'movie',name:'The Last Lighthouse',year:'2024',rating:'8.0',runtime:'1h 52m',cert:'PG',genres:['Drama','Adventure'],pal:['#06121c','#2d7ea8','#ffe9b0'],motif:'beam',
  desc:'The world’s final manned lighthouse is being automated. Its keeper has one winter left to train a replacement who doesn’t want the job.',cast:['Bridget Moore','Ola Sørensen']},
 {id:'ab',type:'movie',name:'Arctic Bloom',year:'2025',rating:'7.6',runtime:'1h 48m',cert:'G',genres:['Documentary','Nature'],pal:['#031a1c','#1cc8a0','#e9fff8'],motif:'aurora',
  desc:'A year on the tundra, filmed in 8K: the six weeks when the frozen north explodes into flower.',cast:['Narrated by Ewa Lind']},
 {id:'qe',type:'movie',name:'Quiet Engines',year:'2023',rating:'7.3',runtime:'2h 02m',cert:'R',genres:['Sci-Fi','Thriller'],pal:['#0a0a0a','#5a5a66','#ff5a3c'],motif:'rings',
  desc:'On a silent generation ship, the chief engineer hears something knocking from outside the hull.',cast:['Theo Grant','Mina Seo']},
 {id:'hs',type:'movie',name:'Hollow Sun',year:'2025',rating:'7.9',runtime:'2h 16m',cert:'PG-13',genres:['Western','Drama'],pal:['#1f0b02','#d9801a','#fff0c2'],motif:'sun',
  desc:'A drought-struck town hires a rainmaker. He promises a storm in seven days. On day six, the sheriff starts digging into his past.',cast:['Wade Carter','Lucía Ferrer']},
];
const byId = Object.fromEntries(T.map(t => [t.id, t]));
const EP_TITLES = ['Carrier Wave','Dead Air','Interference','Night Frequency','The Relay','Feedback','Long Range','Static Bloom','Call Sign','Last Transmission'];
const EP_DESC = ['A message arrives two days before it was sent.','The crew argues over what to do with a warning they can’t verify.','A storm cuts the station off — almost.','Someone at the station has been listening in.','An old relay tower holds the first clue.','The broadcasts start answering back.','A supply plane brings an unexpected visitor.','The aurora goes silent for the first time in years.','They finally learn the sender’s name.','The final broadcast changes everything.'];

/* ---------- Procedural art (SVG) ---------- */
function rng(seed){let h=2166136261;for(const c of seed)h=Math.imul(h^c.charCodeAt(0),16777619);return()=>((h=Math.imul(h^(h>>>15),2246822507),h=Math.imul(h^(h>>>13),3266489909),(h^=h>>>16)>>>0)/4294967296)}
function art(t, w, h, opts = {}){
  const [a,b,c] = t.pal, r = rng(t.id + (opts.seed||'')), id = t.id + (opts.seed||'') + w;
  let g = '';
  const cx = w*(.35+r()*.3), cy = h*(.3+r()*.15), R = Math.min(w,h)*(.22+r()*.12);
  switch(t.motif){
    case 'aurora': for(let i=0;i<5;i++){const y=h*(.18+i*.09);g+=`<path d="M0 ${y} C ${w*.3} ${y-h*.12*r()}, ${w*.6} ${y+h*.15*r()}, ${w} ${y-h*.05}" stroke="${i%2?c:b}" stroke-width="${h*.05}" fill="none" opacity="${.25+r()*.35}" filter="url(#bl${id})"/>`}
      g+=`<path d="M0 ${h*.8} L${w*.25} ${h*.62} L${w*.45} ${h*.74} L${w*.7} ${h*.56} L${w} ${h*.72} V${h} H0z" fill="#02060c"/>`;break;
    case 'bloom': for(let i=0;i<9;i++){const x=w*r(),y=h*(.15+r()*.6),s=R*(.3+r()*.7);g+=`<circle cx="${x}" cy="${y}" r="${s}" fill="${i%3?b:c}" opacity="${.18+r()*.4}" filter="url(#bl${id})"/>`}
      g+=`<path d="M${w*.5} ${h} C ${w*.48} ${h*.7}, ${w*.55} ${h*.55}, ${w*.5} ${h*.4}" stroke="${c}" stroke-width="3" fill="none" opacity=".6"/>`;break;
    case 'waves': g+=`<circle cx="${cx}" cy="${cy}" r="${R}" fill="${c}" opacity=".9"/>`;for(let i=0;i<7;i++){const y=h*(.55+i*.07);g+=`<path d="M0 ${y} Q ${w*.25} ${y-14} ${w*.5} ${y} T ${w} ${y} V${h} H0z" fill="${b}" opacity="${.18+i*.1}"/>`};break;
    case 'sun': g+=`<circle cx="${w*.5}" cy="${h*.52}" r="${R*1.25}" fill="url(#sg${id})"/>`;for(let i=0;i<7;i++){const y=h*(.52+i*.035);g+=`<rect x="0" y="${y}" width="${w}" height="${2+i*1.6}" fill="${a}"/>`}
      g+=`<path d="M0 ${h*.72} L${w*.2} ${h*.6} L${w*.38} ${h*.68} L${w*.62} ${h*.55} L${w*.85} ${h*.66} L${w} ${h*.6} V${h} H0z" fill="${a}"/>`;break;
    case 'orbit': for(let i=0;i<4;i++)g+=`<ellipse cx="${cx}" cy="${cy}" rx="${R*(1+i*.45)}" ry="${R*(.35+i*.15)}" fill="none" stroke="${c}" stroke-width="1.5" opacity="${.5-i*.1}" transform="rotate(-18 ${cx} ${cy})"/>`;
      g+=`<circle cx="${cx}" cy="${cy}" r="${R*.55}" fill="${b}"/><circle cx="${cx+R*1.4}" cy="${cy-R*.3}" r="${R*.12}" fill="${c}"/>`;for(let i=0;i<40;i++)g+=`<circle cx="${w*r()}" cy="${h*r()}" r="${r()*1.4}" fill="#fff" opacity="${r()}"/>`;break;
    case 'city': for(let i=0;i<14;i++){const bw=w*(.05+r()*.08),bh=h*(.15+r()*.4),x=w*r();g+=`<rect x="${x}" y="${h*.78-bh}" width="${bw}" height="${bh}" fill="${a}" stroke="${i%2?b:c}" stroke-width="1.2" opacity=".95"/>`}
      g+=`<rect y="${h*.78}" width="${w}" height="${h*.22}" fill="url(#rf${id})"/>`;break;
    case 'moon': g+=`<circle cx="${cx}" cy="${cy}" r="${R*.8}" fill="${c}"/><circle cx="${cx+R*.3}" cy="${cy-R*.15}" r="${R*.75}" fill="${a}"/>`;
      g+=`<path d="M0 ${h*.7} H${w} V${h} H0z" fill="${b}" opacity=".35"/><path d="M${w*.3} ${h*.68} h${w*.4} l-${w*.05} ${h*.05} h-${w*.3}z" fill="#000"/><rect x="${w*.45}" y="${h*.6}" width="${w*.08}" height="${h*.08}" fill="#000"/><circle cx="${w*.49}" cy="${h*.63}" r="2" fill="${c}"/>`;break;
    case 'mountains': for(let i=0;i<4;i++){const y=h*(.45+i*.1);g+=`<path d="M0 ${y+30} L${w*.2} ${y-20*r()} L${w*.4} ${y+10} L${w*.62} ${y-40*r()} L${w*.82} ${y+5} L${w} ${y-10} V${h} H0z" fill="${i?a:b}" opacity="${.5+i*.15}"/>`};g+=`<circle cx="${cx}" cy="${h*.25}" r="${R*.4}" fill="${c}" opacity=".8"/>`;break;
    case 'grid': for(let i=0;i<14;i++){const y=h*.55+Math.pow(i/13,2)*h*.45;g+=`<line x1="0" y1="${y}" x2="${w}" y2="${y}" stroke="${b}" stroke-width="1.2" opacity=".7"/>`}
      for(let i=-8;i<=8;i++)g+=`<line x1="${w/2}" y1="${h*.55}" x2="${w/2+i*w*.18}" y2="${h}" stroke="${b}" stroke-width="1.2" opacity=".6"/>`;g+=`<circle cx="${w/2}" cy="${h*.45}" r="${R}" fill="url(#sg${id})"/>`;break;
    case 'beam': g+=`<path d="M${w*.5} ${h*.38} L${w} ${h*.2} L${w} ${h*.5}z" fill="${c}" opacity=".35"/><path d="M${w*.5} ${h*.38} L0 ${h*.25} L0 ${h*.45}z" fill="${c}" opacity=".18"/>`;
      g+=`<path d="M${w*.46} ${h*.8} L${w*.48} ${h*.4} h${w*.04} L${w*.54} ${h*.8}z" fill="#eee"/><rect x="${w*.47}" y="${h*.35}" width="${w*.06}" height="${h*.05}" fill="${c}"/><path d="M0 ${h*.8} Q ${w*.5} ${h*.74} ${w} ${h*.8} V${h} H0z" fill="${a}"/>`;break;
    case 'rings': for(let i=0;i<8;i++)g+=`<circle cx="${w/2}" cy="${h*.45}" r="${R*(.3+i*.25)}" fill="none" stroke="${i===3?c:b}" stroke-width="${i===3?3:1}" opacity="${.8-i*.08}"/>`;g+=`<circle cx="${w/2}" cy="${h*.45}" r="${R*.18}" fill="${c}"/>`;break;
  }
  const title = opts.noTitle ? '' : `<text x="${w/2}" y="${h*.9}" text-anchor="middle" font-family="Inter,Helvetica,Arial,sans-serif" font-weight="900" font-size="${Math.min(w*.12, 26*(w/150), (w*.86)/(t.name.length*.68))}" letter-spacing="${w*.008}" fill="#fff" style="text-transform:uppercase">${esc(t.name.toUpperCase())}</text>`;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}"><defs>
   <linearGradient id="bg${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset=".6" stop-color="${b}" stop-opacity=".55"/><stop offset="1" stop-color="${a}"/></linearGradient>
   <radialGradient id="sg${id}"><stop offset="0" stop-color="${c}"/><stop offset="1" stop-color="${b}"/></radialGradient>
   <linearGradient id="rf${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${b}" stop-opacity=".5"/><stop offset="1" stop-color="${a}"/></linearGradient>
   <filter id="bl${id}"><feGaussianBlur stdDeviation="${w*.02}"/></filter></defs>
   <rect width="${w}" height="${h}" fill="url(#bg${id})"/>${g}${title}</svg>`;
  return `url('data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg).replace(/'/g,"%27").replace(/\(/g,"%28").replace(/\)/g,"%29")}')`;
}
const cache = {};
const poster = t => cache['p'+t.id] ||= art(t, 300, 450);
const backdrop = (t, seed='') => cache['b'+t.id+seed] ||= art(t, 1000, 1300, {noTitle:true, seed});
const thumb = (t, n) => cache['t'+t.id+n] ||= art(t, 320, 180, {noTitle:true, seed:'e'+n});

/* ---------- Quality parser (port of StreamQuality.swift) ---------- */
function parseQuality(s){
  const text = [s.name, s.title, s.filename].filter(Boolean).join(' '), t = text.toLowerCase(), has = re => re.test(t);
  const q = {res:0, hdr:[], audio:[], codec:null, container:null, channels:null, remux:false, size:null};
  if (has(/\b(2160p?|4k|uhd)\b/)) q.res=4; else if (has(/\b1080[pi]?\b|\bfhd\b/)) q.res=3; else if (has(/\b720p?\b/)) q.res=2; else if (has(/\b(480p?|576p?|sd)\b/)) q.res=1;
  if (has(/\b(dv|dovi|dolby[ ._-]?vision)\b/)) q.hdr.push('DV');
  if (has(/hdr10\+|hdr10plus/)) q.hdr.push('HDR10+'); else if (has(/\bhdr10\b/)) q.hdr.push('HDR10'); else if (has(/\bhdr\b/)) q.hdr.push('HDR');
  if (has(/\bhlg\b/)) q.hdr.push('HLG');
  if (has(/atmos/)) q.audio.push('Atmos');
  if (has(/truehd/)) q.audio.push('TrueHD');
  if (has(/dts[ ._-]?x\b/)) q.audio.push('DTS:X'); else if (has(/dts[ ._-]?hd/)) q.audio.push('DTS-HD MA'); else if (has(/\bdts\b/)) q.audio.push('DTS');
  if (has(/\b(ddp|dd\+|eac3)/)) q.audio.push('DD+'); else if (has(/\b(dd|ac3)\b/)) q.audio.push('DD');
  if (has(/\baac\b/)) q.audio.push('AAC');
  if (has(/(?<!\d)7[ .]1\b/)) q.channels='7.1'; else if (has(/(?<!\d)5[ .]1\b/)) q.channels='5.1';
  if (has(/\b(hevc|x265|h[ .]?265)\b/)) q.codec='HEVC'; else if (has(/\bav1\b/)) q.codec='AV1'; else if (has(/\b(avc|x264|h[ .]?264)\b/)) q.codec='H.264';
  q.remux = has(/\bremux\b/);
  const m = (s.filename||s.url||'').toLowerCase().match(/\.([a-z0-9]{2,4})(?:$|\?)/); q.container = m ? m[1] : null;
  const sz = text.match(/(\d+(?:[.,]\d+)?)\s?(GB|MB)/i); if (sz) q.size = sz[1] + ' ' + sz[2].toUpperCase();
  const soft = ['TrueHD','DTS:X','DTS-HD MA','DTS'];
  q.native = !(['mkv','avi','webm','ts'].includes(q.container) || q.audio.some(a => soft.includes(a)) || q.codec === 'AV1');
  q.score = q.res*1000 + (q.hdr.includes('DV')?300:q.hdr.includes('HDR10+')?250:q.hdr.length?200:0) + (q.audio.includes('Atmos')?60:q.audio.some(a=>soft.includes(a))?50:q.audio.includes('DD+')?30:0) + (q.remux?40:0);
  return q;
}
function badgesHTML(q){
  const out = [];
  if (q.res) out.push(`<span class="b res">${{4:'4K',3:'1080p',2:'720p',1:'SD'}[q.res]}</span>`);
  q.hdr.forEach(h => out.push(`<span class="b ${h==='DV'?'dv':'hdr'}">${h==='DV'?'DOLBY VISION':h}</span>`));
  q.audio.slice(0,2).forEach(a => out.push(`<span class="b aud">${a}</span>`));
  if (q.channels) out.push(`<span class="b">${q.channels}</span>`);
  if (q.codec) out.push(`<span class="b">${q.codec}</span>`);
  if (q.remux) out.push(`<span class="b remux">REMUX</span>`);
  return out.join('');
}
function streamsFor(t, ep){
  const n = t.name.replace(/[^A-Za-z0-9 ]/g,'').replace(/ /g,'.'), tag = ep ? `.S${String(ep.s).padStart(2,'0')}E${String(ep.e).padStart(2,'0')}` : `.${t.year.slice(0,4)}`;
  const list = [
    {addon:'Home NAS', name:'NAS\n4K', filename:`${n}${tag}.2160p.UHD.BluRay.REMUX.DV.HDR10.HEVC.TrueHD.Atmos.7.1.mkv`, title:'💾 58.3 GB', url:SAMPLE},
    {addon:'Demo Streams', name:'Demo 4K', filename:`${n}${tag}.2160p.WEB-DL.DV.HDR10+.DDP5.1.Atmos.HEVC.mp4`, title:'💾 18.2 GB', url:SAMPLE},
    {addon:'Local Media Server', name:'Jellyfin', filename:`${n}${tag}.2160p.HDR10.HLG.HEVC.DDP5.1.m3u8`, title:'Adaptive HLS · 4K HDR', url:SAMPLE},
    {addon:'Home NAS', name:'NAS\n1080p', filename:`${n}${tag}.1080p.BluRay.x265.DTS-HD.MA.5.1.mkv`, title:'💾 12.4 GB', url:SAMPLE},
    {addon:'Demo Streams', name:'Demo HD', filename:`${n}${tag}.1080p.WEB-DL.DDP5.1.H.264.mp4`, title:'💾 6.1 GB', url:SAMPLE},
    {addon:'Local Media Server', name:'Jellyfin', filename:`${n}${tag}.720p.WEB.x264.AAC.mp4`, title:'💾 1.9 GB', url:SAMPLE},
  ];
  return list.map(s => ({...s, q: parseQuality(s)})).sort((a,b) => b.q.score - a.q.score);
}

/* ---------- State ---------- */
const S = {
  tab:'home', stacks:{home:[], library:[], addons:[], settings:[], search:[]},
  watchlist:new Set(['ns','go','ll']),
  progress:{'ns:1:3':{f:.62,left:18},'go':{f:.35,left:85},'nh:1:2':{f:.2,left:38}},
  player:'auto', external:'Infuse', minRes:0, hdrOnly:false, hideNoLink:true, autoplay:false, glass:12, audioLang:'English', subLang:'Off',
  addons:[
    {id:'cinemeta',name:'Cinemeta',sub:'Official metadata · catalog, meta',color:'#7b5cff',on:true},
    {id:'nas',name:'Home NAS',sub:'Your personal library · stream',color:'#30a46c',on:true},
    {id:'jf',name:'Local Media Server',sub:'Jellyfin bridge · catalog, stream',color:'#0a84ff',on:true},
    {id:'demo',name:'Demo Streams',sub:'Sample streams · stream',color:'#ff375f',on:true},
    {id:'subs',name:'Subtitles',sub:'Community subtitles · subtitles',color:'#ff9f0a',on:true},
  ],
};
const views = $('#views'), tabbar = $('#tabbar'), accessory = $('#accessory');

/* ---------- Navigation ---------- */
function rootFor(tab){ return {home:homeView, library:libraryView, addons:addonsView, settings:settingsView, search:searchView}[tab](); }
function mountPage(html, cls=''){
  const p = document.createElement('section'); p.className = 'page ' + cls; p.innerHTML = html; views.appendChild(p);
  p.addEventListener('scroll', () => onScroll(p), {passive:true}); return p;
}
function showTab(tab){
  if (tab === S.tab && S.stacks[tab].length > 1) { // pop to root
    while (S.stacks[tab].length > 1) S.stacks[tab].pop().el.remove();
  }
  S.tab = tab;
  $$('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  tabbar.classList.toggle('searching', tab === 'search');
  tabbar.classList.remove('min'); accessory.classList.remove('min');
  if (tab === 'search') { const tb=$('.tabs'); $$('.tab',tb).forEach(b=>b.classList.remove('active')); const prev=$(`.tab[data-tab="${S.lastTab||'home'}"]`); prev&&prev.classList.add('active'); }
  else S.lastTab = tab;
  if (!S.stacks[tab].length) { const el = mountPage(rootFor(tab)); S.stacks[tab].push({el}); wire(el); }
  $$('.page', views).forEach(p => p.classList.add('hidden'));
  const top = S.stacks[tab].at(-1).el; top.classList.remove('hidden','under','enter');
  accessory.classList.toggle('hide', tab === 'search' || tab === 'settings' || tab === 'addons');
  if (tab === 'search') setTimeout(() => $('#searchInput').focus({preventScroll:true}), 450);
}
function push(html, {zoomFrom}={}){
  const stack = S.stacks[S.tab], prev = stack.at(-1).el;
  const el = mountPage(html, zoomFrom ? 'zoom-enter' : 'enter');
  if (zoomFrom) { const r = zoomFrom.getBoundingClientRect(), sr = $('#screen').getBoundingClientRect(), sc = sr.width/ $('#screen').offsetWidth;
    el.style.transformOrigin = `${(r.left - sr.left + r.width/2)/sc}px ${(r.top - sr.top + r.height/2)/sc}px`; }
  stack.push({el}); wire(el);
  requestAnimationFrame(() => requestAnimationFrame(() => { el.classList.remove('enter','zoom-enter'); prev.classList.add('under'); }));
  setTimeout(() => prev.classList.add('hidden'), 520);
  tabbar.classList.remove('min'); accessory.classList.remove('min');
  return el;
}
function pop(){
  const stack = S.stacks[S.tab]; if (stack.length < 2) return;
  const cur = stack.pop().el, prev = stack.at(-1).el;
  prev.classList.remove('hidden'); requestAnimationFrame(() => { prev.classList.remove('under'); cur.classList.add('enter'); });
  setTimeout(() => cur.remove(), 520);
}
let lastY = 0;
function onScroll(p){
  const y = p.scrollTop, nb = $('.navbar', p);
  nb && nb.classList.toggle('scrolled', y > 260 || (nb.dataset.small && y > 40));
  if (S.tab !== 'search') {
    if (y > lastY + 6 && y > 80) { tabbar.classList.add('min'); accessory.classList.add('min'); }
    else if (y < lastY - 6) { tabbar.classList.remove('min'); accessory.classList.remove('min'); }
  }
  lastY = y;
}

/* ---------- Views ---------- */
const posterHTML = (t, extra='') => `<button class="poster" data-open="${t.id}" aria-label="${esc(t.name)}"><span class="art" style="background-image:${poster(t)}">${extra}</span><span class="name">${esc(t.name)}</span></button>`;
const shelf = (title, items, sub='') => `<section class="shelf"><h2>${title}${sub?` <small>›</small>`:''}</h2><div class="row">${items}</div></section>`;
function homeView(){
  const hero = ['ns','sa','go','nh','ll'].map(id => byId[id]);
  const cw = Object.entries(S.progress).map(([k,p]) => { const [id,s,e] = k.split(':'), t = byId[id];
    return `<button class="wide" data-open="${id}"><span class="art" style="background-image:${s?thumb(t,+e):backdrop(t,'w')}"><span class="progress"><b style="width:${p.f*100}%"></b></span></span><span class="name">${esc(t.name)}</span><small>${s?`S${s} · E${e} — `:''}${p.left} min left</small></button>`; }).join('');
  return `
  <div class="hero"><div class="hero-track" id="heroTrack">${hero.map((t,i) => `
    <div class="hero-slide ${i?'':'active'}" data-i="${i}"><div class="bg" style="background-image:${backdrop(t)}"></div>
      <div class="hero-info"><span class="hero-kicker">${t.type==='series'?'New season':'New in 4K HDR'}</span><h2 class="hero-title">${esc(t.name)}</h2>
        <span class="hero-genres">${t.genres.join(' · ')} · ${t.year}</span>
        <div class="hero-actions"><button class="glass-btn prominent" data-open="${t.id}">${ICON.play} Watch now</button>
        <button class="glass-btn glass circle" data-wl="${t.id}" aria-label="Add to library">${S.watchlist.has(t.id)?ICON.check:ICON.plus}</button></div></div></div>`).join('')}
  </div><div class="dots">${hero.map((_,i)=>`<i class="${i?'':'on'}"></i>`).join('')}</div></div>
  ${shelf('Continue Watching', cw)}
  ${shelf('Popular Movies', T.filter(t=>t.type==='movie').slice(0,7).map(t=>posterHTML(t)).join(''), 1)}
  ${shelf('Popular Series', T.filter(t=>t.type==='series').map(t=>posterHTML(t)).join(''), 1)}
  ${shelf('4K Dolby Vision', ['ab','ll','sa','hs','qe','mf'].map(id=>posterHTML(byId[id], '<span class="badge4k glass">4K DV</span>')).join(''), 1)}
  <div style="height:190px"></div>`;
}
function navbar(title, {small}={}){ return `<header class="navbar" ${small?'data-small="1"':''}><button class="nav-btn glass" data-back aria-label="Back">${ICON.back}</button><span class="nav-title">${esc(title)}</span><span style="width:44px"></span></header>`; }
function detailView(id){
  const t = byId[id];
  const body = t.type === 'series' ? seriesBody(t) : `<h3 class="section-h">Streams</h3>${streamsBlock(t, null)}`;
  const nextLabel = t.type==='series' ? (S.progress[`${t.id}:1:3`] ? 'Resume S1 E3' : 'Play S1 E1') : (S.progress[t.id] ? 'Resume' : 'Play best');
  return `${navbar(t.name)}
  <div class="backdrop" style="background-image:${backdrop(t)}"><div class="title-block"><h1 class="d-title">${esc(t.name)}</h1>
    <div class="meta-line"><span>${t.year}</span>·<span>${t.runtime}</span>·<span class="star">★ ${t.rating}</span><span class="pill">${t.cert}</span><span class="pill">4K</span><span class="pill">DV</span><span class="pill">ATMOS</span></div></div></div>
  <div class="pad">
    <div class="actions"><button class="glass-btn prominent" data-primary="${t.id}">${ICON.play} ${nextLabel}</button>
    <button class="glass-btn glass circle" data-wl="${t.id}" aria-label="Add to library">${S.watchlist.has(t.id)?ICON.check:ICON.plus}</button></div>
    <div class="genres">${t.genres.map(g=>`<span>${g}</span>`).join('')}</div>
    <p class="desc" data-desc>${esc(t.desc)}</p>
    <p class="cast">Starring ${t.cast.join(', ')}</p>
    ${body}
  </div><div style="height:180px"></div>`;
}
function seriesBody(t, season=1){
  const eps = Array.from({length: season===1?8:6}, (_,i) => i+1);
  return `<div class="chips" style="margin-top:22px" data-seasons="${t.id}">${Array.from({length:t.seasons},(_,i)=>`<button class="chip ${i+1===season?'on':''}" data-season="${i+1}">Season ${i+1}</button>`).join('')}</div>
  <div class="episodes" id="eps">${eps.map(e => { const p = S.progress[`${t.id}:${season}:${e}`];
    return `<button class="ep" data-ep="${t.id}:${season}:${e}"><span class="thumb" style="background-image:${thumb(t, season*10+e)}">${ICON.play}${p?`<span class="progress"><b style="width:${p.f*100}%"></b></span>`:''}</span>
    <span><small>Episode ${e} · ${40+((e*7)%15)} min</small><strong>${EP_TITLES[(e-1+season*3)%10]}</strong><p>${EP_DESC[(e-1+season*3)%10]}</p></span></button>`; }).join('')}</div>`;
}
function streamsBlock(t, ep){
  return `<div class="chips" data-filters><button class="chip on" data-f="all">All</button><button class="chip" data-f="4">4K</button><button class="chip" data-f="3">1080p</button><button class="chip" data-f="2">720p</button><button class="chip" data-f="hdr">HDR / DV</button></div>
  <div class="loading-row" data-loading><span class="spinner"></span><span>Asking Home NAS, Local Media Server, Demo Streams…</span></div>
  <div class="streams" data-streams="${t.id}${ep?`:${ep.s}:${ep.e}`:''}"></div>`;
}
function episodeView(key){
  const [id,s,e] = key.split(':'), t = byId[id], title = EP_TITLES[(+e-1+ +s*3)%10];
  return `${navbar(`S${s} E${e} · ${title}`, {small:1})}<div style="height:110px"></div><div class="pad">
    <div class="wide" style="width:100%;pointer-events:none"><span class="art" style="height:190px;background-image:${thumb(t, +s*10+ +e)}"></span></div>
    <h1 class="d-title" style="font-size:26px;margin-top:14px">${esc(title)}</h1>
    <div class="meta-line"><span>${esc(t.name)}</span>·<span>Season ${s}, Episode ${e}</span></div>
    <p class="desc" style="margin-top:10px">${EP_DESC[(+e-1+ +s*3)%10]}</p>
    <h3 class="section-h">Streams</h3>${streamsBlock(t, {s,e})}</div><div style="height:160px"></div>`;
}
function libraryView(){
  const wl = [...S.watchlist].map(id => posterHTML(byId[id])).join('');
  const cw = Object.entries(S.progress).map(([k,p]) => { const [id,s,e] = k.split(':'), t = byId[id];
    return `<button class="cell" data-open="${id}"><span class="icon-tile" style="width:46px;height:68px;border-radius:10px;background:${poster(t)} center/cover"></span><span class="grow"><span class="label">${esc(t.name)}</span><span class="sub">${s?`S${s} · E${e} · `:''}${p.left} min left</span><span class="progress" style="position:relative;display:block;left:0;right:0;bottom:0;margin-top:8px;background:rgba(255,255,255,.15)"><b style="width:${p.f*100}%"></b></span></span></button>`; }).join('');
  return `<h1 class="large-title">Library</h1><div class="group-h">Continue watching</div><div class="group">${cw}</div>
  <div class="group-h">My library</div>${wl ? `<div class="grid">${wl}</div>` : '<p class="empty">Titles you add appear here.</p>'}<div style="height:200px"></div>`;
}
function addonsView(){
  return `<h1 class="large-title">Addons</h1>
  <div class="group-h">Add addon</div><div class="field"><input id="addonUrl" placeholder="https://…/manifest.json or stremio://…" autocomplete="off" inputmode="url"><button class="glass-btn prominent" data-install>Install</button></div>
  <p class="group-foot">Paste the manifest URL of any Stremio-compatible addon. Only install addons for content you have the right to stream.</p>
  <div class="group-h">Installed</div><div class="group" id="addonList">${S.addons.map(addonCell).join('')}</div>
  <p class="group-foot">Order sets priority when loading streams. Long-press to copy a manifest URL.</p><div style="height:200px"></div>`;
}
const addonCell = a => `<div class="cell"><span class="icon-tile" style="background:${a.color}">${a.name.split(' ').map(w=>w[0]).join('').slice(0,2)}</span><span class="grow"><span class="label">${esc(a.name)}</span><span class="sub">${esc(a.sub)}</span></span><button class="switch ${a.on?'on':''}" data-addon="${a.id}" aria-label="Enable ${esc(a.name)}"></button></div>`;
function settingsView(){
  const players = [['auto','Automatic','Apple for MP4/HLS, VLC for MKV/DTS/TrueHD'],['native','Apple player','True HDR10 · Dolby Vision · Atmos · PiP'],['vlc','VLC engine','MKV · DTS · TrueHD · ASS/PGS subtitles'],['external','External player','Hands the link to another app']];
  const ext = ['Infuse','VLC','Outplayer','nPlayer','SenPlayer','VidHub'];
  const hdr = matchMedia('(dynamic-range: high)').matches;
  return `<h1 class="large-title">Settings</h1>
  <div class="group-h">Default player</div><div class="group">${players.map(([k,l,s])=>`<button class="cell ${S.player===k?'selected':''}" data-player="${k}"><span class="grow"><span class="label">${l}</span><span class="sub">${s}</span></span><span class="check">✓</span></button>`).join('')}</div>
  <div class="group-h">External player</div><div class="group">${ext.map(p=>`<button class="cell ${S.external===p?'selected':''}" data-ext="${p}"><span class="icon-tile" style="background:${{Infuse:'#f25c05',VLC:'#ff8800',Outplayer:'#2f80ed',nPlayer:'#34c759',SenPlayer:'#5e5ce6',VidHub:'#ff2d55'}[p]}">${p[0]}</span><span class="grow"><span class="label">${p}</span></span><span class="check">✓</span></button>`).join('')}</div>
  <div class="group-h">Stream filters</div><div class="seg" data-seg="minRes">${[['Any',0],['720p',2],['1080p',3],['4K',4]].map(([l,v])=>`<button class="${S.minRes===v?'on':''}" data-v="${v}">${l}</button>`).join('')}</div>
  <div class="group" style="margin-top:12px">
    ${toggle('hdrOnly','HDR / Dolby Vision only')}${toggle('hideNoLink','Hide streams without a direct link')}${toggle('autoplay','Autoplay best stream')}</div>
  <div class="group-h">Appearance · iOS 27</div><div class="group"><div class="slider-cell"><span class="label">Liquid Glass</span><input type="range" min="2" max="60" value="${S.glass}" id="glassSlider" aria-label="Liquid Glass tint"><div class="ends"><span>Clear</span><span>Tinted</span></div></div></div>
  <div class="group-h">Languages</div><div class="group">
    <button class="cell" data-cycle="audioLang"><span class="grow label">Preferred audio</span><span class="value">${S.audioLang}</span></button>
    <button class="cell" data-cycle="subLang"><span class="grow label">Preferred subtitles</span><span class="value">${S.subLang}</span></button></div>
  <div class="group-h">This device</div><div class="group">
    <div class="cell"><span class="grow label">HDR display</span><span class="value">${hdr?'Supported':'Not detected'}</span></div>
    <div class="cell"><span class="grow label">Dolby Vision / HDR10 decode</span><span class="value">iPhone 12 or newer</span></div>
    <div class="cell"><span class="grow label">Version</span><span class="value">1.0 (demo)</span></div></div>
  <div style="height:200px"></div>`;
}
const toggle = (k,l) => `<div class="cell"><span class="grow label">${l}</span><button class="switch ${S[k]?'on':''}" data-toggle="${k}" aria-label="${l}"></button></div>`;
function searchView(){
  const tiles = [['Movies','go'],['Series','nh'],['4K HDR','sa'],['Dolby Vision','ab'],['Dolby Atmos','qe'],['Documentary','ll']];
  return `<h1 class="large-title">Search</h1><div id="searchBody"><div class="tiles">${tiles.map(([l,id])=>`<button class="tile" data-q="${l}" style="background-image:linear-gradient(180deg,transparent,rgba(0,0,0,.55)),${backdrop(byId[id],'tile')}">${l}</button>`).join('')}</div></div><div style="height:200px"></div>`;
}
function renderSearch(q){
  const body = $('#searchBody'); if (!body) return;
  q = q.trim().toLowerCase();
  if (!q) { const p = S.stacks.search[0].el; p.innerHTML = searchView(); wire(p); return; }
  const map = {'movies':t=>t.type==='movie','series':t=>t.type==='series','4k hdr':()=>true,'dolby vision':t=>['ab','ll','sa','hs','qe','mf'].includes(t.id),'dolby atmos':t=>['qe','sa','ns','nh'].includes(t.id),'documentary':t=>t.genres.includes('Documentary')||t.genres.includes('Drama')};
  const res = T.filter(map[q] || (t => (t.name+' '+t.genres.join(' ')).toLowerCase().includes(q)));
  body.innerHTML = res.length ? `<div class="group-h" style="margin-left:20px">${res.length} result${res.length>1?'s':''} · Cinemeta, Local Media Server</div><div class="grid">${res.map(t=>posterHTML(t)).join('')}</div>` : `<p class="empty">No results for “${esc(q)}”.</p>`;
}

/* ---------- Wiring ---------- */
function wire(root){
  root.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.back !== undefined) return pop();
    if (b.dataset.open) return openDetail(b.dataset.open, b.querySelector('.art') || b);
    if (b.dataset.wl) { const id=b.dataset.wl; S.watchlist.has(id)?S.watchlist.delete(id):S.watchlist.add(id); $$(`[data-wl="${id}"]`).forEach(x=>x.innerHTML=S.watchlist.has(id)?ICON.check:ICON.plus); toast(S.watchlist.has(id)?'Added to Library':'Removed from Library'); refreshRoot('library'); return; }
    if (b.dataset.primary) return primary(b.dataset.primary);
    if (b.dataset.season) { const wrap=b.closest('[data-seasons]'), t=byId[wrap.dataset.seasons]; $$('.chip',wrap).forEach(c=>c.classList.toggle('on',c===b)); const tmp=document.createElement('div'); tmp.innerHTML=seriesBody(t,+b.dataset.season); $('#eps',root).replaceWith($('#eps',tmp)); return; }
    if (b.dataset.ep) { const el = push(episodeView(b.dataset.ep)); return loadStreams(el); }
    if (b.dataset.f) { const wrap=b.closest('[data-filters]'); $$('.chip',wrap).forEach(c=>c.classList.toggle('on',c===b)); applyFilter(root, b.dataset.f); return; }
    if (b.dataset.stream) return playStream(JSON.parse(b.dataset.stream));
    if (b.dataset.player) { S.player=b.dataset.player; $$('[data-player]',root).forEach(c=>c.classList.toggle('selected',c===b)); toast(`Default player: ${b.querySelector('.label').textContent}`); return; }
    if (b.dataset.ext) { S.external=b.dataset.ext; $$('[data-ext]',root).forEach(c=>c.classList.toggle('selected',c===b)); return; }
    if (b.dataset.toggle) { S[b.dataset.toggle]=!S[b.dataset.toggle]; b.classList.toggle('on'); return; }
    if (b.dataset.addon) { const a=S.addons.find(x=>x.id===b.dataset.addon); a.on=!a.on; b.classList.toggle('on'); toast(`${a.name} ${a.on?'enabled':'disabled'}`); return; }
    if (b.dataset.install !== undefined) return installAddon(root);
    if (b.dataset.cycle) { const k=b.dataset.cycle, opts=k==='audioLang'?['English','Svenska','Español','日本語']:['Off','English','Svenska','Español']; S[k]=opts[(opts.indexOf(S[k])+1)%opts.length]; $('.value',b).textContent=S[k]; return; }
    if (b.dataset.q) { $('#searchInput').value=b.dataset.q; renderSearch(b.dataset.q); return; }
    if (b.closest('.seg')) { const seg=b.closest('.seg'); $$('button',seg).forEach(x=>x.classList.toggle('on',x===b)); S[seg.dataset.seg]=+b.dataset.v; return; }
  });
  root.addEventListener('contextmenu', e => { const s = e.target.closest('[data-stream]'); if (s) { e.preventDefault(); streamMenu(JSON.parse(s.dataset.stream)); } });
  const desc = $('[data-desc]', root); desc && desc.addEventListener('click', () => desc.classList.toggle('open'));
  const gs = $('#glassSlider', root); gs && gs.addEventListener('input', () => { S.glass=+gs.value; document.documentElement.style.setProperty('--glass-a', (S.glass/100).toFixed(2)); });
  const track = $('#heroTrack', root); if (track) heroBehaviour(root, track);
  if ($('[data-streams]', root)) loadStreams(root);
}
function refreshRoot(tab){ const st=S.stacks[tab]; if (!st.length) return; const old = st[0].el, el = mountPage(rootFor(tab)); el.className = old.className; old.replaceWith(el); st[0].el = el; wire(el); }
function heroBehaviour(root, track){
  const slides = $$('.hero-slide', track), dots = $$('.dots i', root); let i = 0, timer;
  const set = n => { i = n; slides.forEach((s,k)=>s.classList.toggle('active',k===n)); dots.forEach((d,k)=>d.classList.toggle('on',k===n)); };
  track.addEventListener('scroll', () => { const n = Math.round(track.scrollLeft / track.clientWidth); if (n !== i) set(n); }, {passive:true});
  const auto = () => { clearInterval(timer); timer = setInterval(() => { if (!document.body.contains(track)) return clearInterval(timer); if (track.closest('.hidden')) return; track.scrollTo({left: ((i+1)%slides.length)*track.clientWidth, behavior:'smooth'}); }, 5200); };
  track.addEventListener('pointerdown', auto); auto();
}
function openDetail(id, from){ push(detailView(id), {zoomFrom: from}); }
function primary(id){
  const t = byId[id];
  if (t.type === 'series') { const el = push(episodeView(`${id}:1:3`)); loadStreams(el); return; }
  const best = streamsFor(t).find(s => passes(s));
  best && playStream({t:id, i:0, ep:null});
}
function passes(s){ return s.q.res >= S.minRes && (!S.hdrOnly || s.q.hdr.length); }
function loadStreams(root){
  const box = $('[data-streams]', root); if (!box || box.dataset.loaded) return; box.dataset.loaded = 1;
  const [id,s,e] = box.dataset.streams.split(':'), t = byId[id], ep = s ? {s,e} : null;
  const list = streamsFor(t, ep);
  setTimeout(() => {
    $('[data-loading]', root)?.remove();
    box.innerHTML = list.map((st,i) => passes(st) ? `<button class="stream" data-stream='${JSON.stringify({t:id,i,ep})}' data-res="${st.q.res}" data-hdr="${st.q.hdr.length?1:0}" style="animation-delay:${i*60}ms">
      <div class="badges">${badgesHTML(st.q)}</div>${st.q.size?`<span class="size">${st.q.size}</span>`:''}
      <span class="more" data-more aria-label="More options">${ICON.more}</span>
      <p class="file">${esc(st.filename)}</p>
      <div class="foot"><span>${esc(st.addon)} · ${esc(st.name.replace('\n',' '))}</span><span class="engine ${engineFor(st)==='Apple player'?'native':'vlc'}">${S.player==='external'?S.external:engineFor(st)}</span></div></button>` : '').join('') || '<p class="empty">No streams match your filters.</p>';
    $$('[data-more]', box).forEach(m => m.addEventListener('click', ev => { ev.stopPropagation(); streamMenu(JSON.parse(m.closest('[data-stream]').dataset.stream)); }));
    if (S.autoplay) { const f = $('[data-stream]', box); f && playStream(JSON.parse(f.dataset.stream)); }
  }, 900);
}
function applyFilter(root, f){
  $$('[data-stream]', root).forEach(s => { const ok = f==='all' || (f==='hdr' ? s.dataset.hdr==='1' : s.dataset.res===f); s.style.display = ok ? '' : 'none'; });
}
function engineFor(st){ if (S.player==='native') return 'Apple player'; if (S.player==='vlc') return 'VLC engine'; return st.q.native ? 'Apple player' : 'VLC engine'; }

/* ---------- Sheet / toast ---------- */
const scrim = $('#scrim'), sheet = $('#sheet');
function openSheet(html){ sheet.innerHTML = `<div class="grabber"></div>${html}<button class="cancel" data-close>Cancel</button>`; scrim.classList.add('on'); sheet.classList.add('on');
  $$('[data-close]', sheet).forEach(b => b.addEventListener('click', closeSheet)); }
function closeSheet(){ scrim.classList.remove('on'); sheet.classList.remove('on'); }
scrim.addEventListener('click', closeSheet);
function streamMenu(ref){
  const t = byId[ref.t], st = streamsFor(t, ref.ep)[ref.i];
  openSheet(`<h3>${esc(t.name)}${ref.ep?` · S${ref.ep.s} E${ref.ep.e}`:''}</h3><p class="sheet-sub">${esc(st.filename)}</p>
   <button class="opt" data-eng="Apple player"><span class="icon-tile" style="background:#ff375f">${ICON.play}</span><span>Play in Apple player<small>HDR10 · Dolby Vision · Atmos · PiP</small></span></button>
   <button class="opt" data-eng="VLC engine"><span class="icon-tile" style="background:#ff8800">${ICON.play}</span><span>Play in VLC engine<small>MKV · DTS · TrueHD · all subtitles</small></span></button>
   <button class="opt" data-eng="external"><span class="icon-tile" style="background:#5e5ce6">${ICON.ext}</span><span>Open in ${S.external}<small>Change the external player in Settings</small></span></button>
   <button class="opt" data-copy><span class="icon-tile" style="background:#3a3a3c">${ICON.copy}</span><span>Copy stream link</span></button>`);
  $$('[data-eng]', sheet).forEach(b => b.addEventListener('click', () => { closeSheet(); setTimeout(() => playStream(ref, b.dataset.eng), 300); }));
  $('[data-copy]', sheet).addEventListener('click', () => { closeSheet(); navigator.clipboard?.writeText(SAMPLE).catch(()=>{}); toast('Stream link copied'); });
}
let toastT;
function toast(msg){ const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2200); }
function installAddon(root){
  const inp = $('#addonUrl', root), v = inp.value.trim();
  if (!v) { inp.focus(); toast('Paste a manifest URL first'); return; }
  let host = v.replace(/^(stremio|https?):\/\//,'').split('/')[0] || 'custom';
  toast('Fetching manifest…');
  setTimeout(() => { const a = {id:'c'+Date.now(), name: host.split('.')[0].replace(/^\w/, c=>c.toUpperCase()) + ' Addon', sub: host + ' · catalog, stream', color:'#64d2ff', on:true};
    S.addons.push(a); $('#addonList', root).insertAdjacentHTML('beforeend', addonCell(a)); inp.value=''; toast(`Installed ${a.name}`); }, 900);
}

/* ---------- Player ---------- */
const player = $('#player'), device = $('#device');
let hideT;
function playStream(ref, forced){
  const t = byId[ref.t], st = streamsFor(t, ref.ep)[ref.i];
  const mode = forced || (S.player === 'external' ? 'external' : engineFor(st));
  if (mode === 'external') { toast(`Opening in ${S.external}…`); return; }
  const title = t.name + (ref.ep ? ` — S${ref.ep.s} E${ref.ep.e}` : '');
  const audio = [ 'English · Dolby Atmos 7.1', 'English · TrueHD 7.1', 'Svenska · DD+ 5.1', 'English · Commentary AAC 2.0' ];
  const subs = [ 'Off', 'English', 'English SDH', 'Svenska', 'Español (addon)' ];
  player.innerHTML = `<div class="p-inner" id="pInner">
    <div class="fallback-art" style="background-image:${backdrop(t,'p')}"></div>
    <video id="vid" playsinline preload="auto" src="${SAMPLE}"></video>
    <div class="p-ui" id="pui">
      <div class="p-top glass"><button class="p-icon" data-x aria-label="Close">${ICON.close}</button>
        <div class="t"><strong>${esc(title)}</strong><small>${mode} · ${esc(st.addon)}</small></div>
        <button class="p-icon" data-tracks aria-label="Audio and subtitles">${ICON.cc}</button>
        ${mode==='Apple player'?`<button class="p-icon" aria-label="Picture in Picture" data-pip>${ICON.pip}</button><button class="p-icon" aria-label="AirPlay" data-air>${ICON.airplay}</button>`:''}
      </div>
      <div class="p-mid"><button class="glass-btn glass" data-rw aria-label="Back 10 seconds">${ICON.rw}</button><button class="glass-btn glass big" data-pp aria-label="Play or pause">${ICON.pause}</button><button class="glass-btn glass" data-ff aria-label="Forward 10 seconds">${ICON.ff}</button></div>
      <div class="p-bot glass"><div class="scrub" id="scrub"><div class="rail"><div class="buf" id="buf"></div><div class="fill" id="fill"></div></div><div class="knob" id="knob"></div></div>
        <div class="p-times"><span id="cur">0:00</span><span id="rem">-0:00</span></div><div class="p-tags">${badgesHTML(st.q)}</div></div>
    </div>
    <div class="tracks glass" id="tracks"><h4>Audio</h4>${audio.map((a,i)=>`<button class="${i?'':'on'}" data-a>${a}<span class="ck">✓</span></button>`).join('')}<h4>Subtitles</h4>${subs.map((a,i)=>`<button class="${(S.subLang==='Off'?0:1)===i?'on':''}" data-s>${a}<span class="ck">✓</span></button>`).join('')}</div>
    <span class="credit">Sample video: Big Buck Bunny © Blender Foundation · CC BY 3.0</span>
  </div>`;
  player.classList.add('on'); player.setAttribute('aria-hidden','false');
  const small = matchMedia('(max-width:560px)').matches;
  if (!small) device.classList.add('landscape');
  const v = $('#vid'), ui = $('#pui'), tracks = $('#tracks');
  v.addEventListener('loadeddata', () => $('.fallback-art', player)?.remove(), {once:true});
  v.addEventListener('error', () => toast('Sample video could not load — controls still work'));
  setTimeout(() => v.play().catch(() => setPP()), 400);
  const fmt = s => { if (!isFinite(s)) return '0:00'; s=Math.floor(s); const h=s/3600|0,m=(s%3600)/60|0,x=s%60; return (h?h+':'+String(m).padStart(2,'0'):m)+':'+String(x).padStart(2,'0'); };
  const setPP = () => { $('[data-pp]').innerHTML = v.paused ? ICON.play : ICON.pause; };
  v.addEventListener('play', setPP); v.addEventListener('pause', setPP);
  v.addEventListener('timeupdate', () => { const p = v.currentTime/(v.duration||1); $('#fill').style.width=p*100+'%'; $('#knob').style.left=p*100+'%'; $('#cur').textContent=fmt(v.currentTime); $('#rem').textContent='-'+fmt((v.duration||0)-v.currentTime);
    if (v.buffered.length) $('#buf').style.width = v.buffered.end(v.buffered.length-1)/(v.duration||1)*100+'%'; });
  const bump = () => { ui.classList.remove('hidden'); clearTimeout(hideT); hideT = setTimeout(() => { if (!v.paused && !tracks.classList.contains('on')) ui.classList.add('hidden'); }, 3500); };
  $('#pInner').addEventListener('click', e => { if (e.target === v || e.target === ui || e.target.classList.contains('p-mid')) { if (ui.classList.contains('hidden')) bump(); else { ui.classList.add('hidden'); tracks.classList.remove('on'); } } });
  $('[data-pp]').onclick = () => { v.paused ? v.play() : v.pause(); bump(); };
  $('[data-rw]').onclick = () => { v.currentTime = Math.max(0, v.currentTime-10); bump(); };
  $('[data-ff]').onclick = () => { v.currentTime += 10; bump(); };
  $('[data-tracks]').onclick = () => { tracks.classList.toggle('on'); bump(); };
  $$('[data-pip],[data-air]').forEach(b => b.onclick = () => toast(b.dataset.pip!==undefined ? 'Picture in Picture works on iPhone' : 'AirPlay: choose an Apple TV on iPhone'));
  $$('#tracks [data-a]').forEach(b => b.onclick = () => { $$('#tracks [data-a]').forEach(x=>x.classList.toggle('on',x===b)); toast('Audio: '+b.firstChild.textContent); });
  $$('#tracks [data-s]').forEach(b => b.onclick = () => { $$('#tracks [data-s]').forEach(x=>x.classList.toggle('on',x===b)); toast('Subtitles: '+b.firstChild.textContent); });
  const scrub = $('#scrub'); const seek = e => { const r = scrub.getBoundingClientRect(); const horiz = !device.classList.contains('landscape') || small;
    const p = horiz ? (e.clientX - r.left)/r.width : (e.clientY - r.top)/r.height; if (v.duration) v.currentTime = Math.min(Math.max(p,0),1)*v.duration; bump(); };
  scrub.addEventListener('pointerdown', e => { seek(e); const mv = ev => seek(ev); window.addEventListener('pointermove', mv); window.addEventListener('pointerup', () => window.removeEventListener('pointermove', mv), {once:true}); });
  $('[data-x]').onclick = closePlayer;
  bump();
}
function closePlayer(){ const v = $('#vid'); v && v.pause(); device.classList.remove('landscape'); player.classList.remove('on'); player.setAttribute('aria-hidden','true'); setTimeout(() => player.innerHTML = '', 500); }

/* ---------- Tabs, accessory, search, guide ---------- */
$$('[data-tab]').forEach(b => b.addEventListener('click', () => showTab(b.dataset.tab)));
$('#searchInput').addEventListener('input', e => renderSearch(e.target.value));
$('#accArt').style.backgroundImage = thumb(byId.ns, 13);
accessory.addEventListener('click', () => playStream({t:'ns', i:1, ep:{s:'1',e:'3'}}));
function go(where){
  closeSheet(); if (player.classList.contains('on')) closePlayer();
  const reset = tab => { S.stacks[tab].forEach(x=>x.el.remove()); S.stacks[tab] = []; };
  if (where === 'home') { reset('home'); showTab('home'); }
  else if (where === 'series') { reset('home'); showTab('home'); setTimeout(() => openDetail('ns', $('[data-open="ns"] .art') ), 120); }
  else if (where === 'streams') { reset('home'); showTab('home'); setTimeout(() => { openDetail('sa'); setTimeout(() => { const p = S.stacks.home.at(-1).el; const h = $('.section-h', p); p.scrollTo({top: h.offsetTop - 120, behavior:'smooth'}); }, 650); }, 120); }
  else if (where === 'player') { setTimeout(() => playStream({t:'sa', i:0, ep:null}), 100); }
  else showTab(where);
}
$$('[data-go]').forEach(b => b.addEventListener('click', () => go(b.dataset.go)));
document.addEventListener('keydown', e => { if (e.key === 'Escape') { if (player.classList.contains('on')) closePlayer(); else if (sheet.classList.contains('on')) closeSheet(); else pop(); } });

/* fit device to viewport */
function fit(){
  const wrap = $('.device-wrap'), W = wrap.clientWidth - 20, H = window.innerHeight - 30;
  document.documentElement.style.setProperty('--fit', Math.min(1, H/876, W/417).toFixed(3));
  document.documentElement.style.setProperty('--fit-l', Math.min(1, W/876, H/417).toFixed(3));
}
addEventListener('resize', fit); fit();
showTab('home');
})();
